import { useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { getLevelIcon } from "../../utils/gamification";
import {
  FiHome,
  FiUser,
  FiSettings,
  FiAward,
  FiLogOut,
  FiBell,
  FiMenu,
  FiX,
  FiShield,
  FiBookOpen,
  FiUsers,
} from "react-icons/fi";

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Header({ currentPage, onNavigate }: HeaderProps) {
  const { user, profile, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    onNavigate("home");
    setMenuOpen(false);
  };

  const navItems = [
    { id: "feed", label: "Feed", icon: FiHome },
    { id: "profile", label: "Perfil", icon: FiUser },
    { id: "ranking", label: "Ranking", icon: FiAward },
    { id: "institutions", label: "Instituições", icon: FiBookOpen },
    ...(profile?.role === "admin" || profile?.role === "moderator"
      ? [{ id: "moderation", label: "Moderação", icon: FiShield }]
      : []),
    ...(profile && profile.birthDate && !profile.isMinor
      ? [{ id: "guardian", label: "Autorizações", icon: FiUsers }]
      : []),
    { id: "settings", label: "Configurações", icon: FiSettings },
  ];

  return (
    <header className="sticky top-0 z-50 border-b border-blue-900/20 bg-gradient-to-r from-blue-950 via-blue-900 to-blue-950 shadow-lg backdrop-blur-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        {/* Logo */}
        <button
          onClick={() => onNavigate("home")}
          className="flex items-center gap-2 transition-transform hover:scale-105"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg shadow-blue-500/30">
            <span className="text-xl font-bold text-white">Z</span>
          </div>
          <div className="text-left">
            <h1 className="text-lg font-bold text-white">Zuca Social</h1>
            <p className="text-[10px] text-blue-300/70">Nexus Technology</p>
          </div>
        </button>

        {/* Desktop Nav */}
        {user && (
          <nav className="hidden items-center gap-1 md:flex">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm font-medium transition-all ${
                    currentPage === item.id
                      ? "bg-white/15 text-white shadow-inner"
                      : "text-white/70 hover:bg-white/10 hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        )}

        {/* Right Side */}
        <div className="flex items-center gap-3">
          {user && profile && (
            <>
              {/* Notifications */}
              <button className="relative rounded-full p-2 text-white/80 transition-colors hover:bg-white/10 hover:text-white">
                <FiBell className="h-5 w-5" />
              </button>

              {/* User Badge */}
              <div className="hidden items-center gap-2 sm:flex">
                <span className="text-sm">
                  {getLevelIcon(profile.gamification.level)}
                </span>
                <span className="text-xs font-medium text-white/80">
                  {profile.gamification.points} pts
                </span>
              </div>

              {/* Avatar */}
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-sm font-bold text-white shadow-md">
                  {profile.displayName?.[0]?.toUpperCase() || "U"}
                </div>
              </div>
            </>
          )}

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="rounded-lg p-2 text-white transition-colors hover:bg-white/10 md:hidden"
          >
            {menuOpen ? (
              <FiX className="h-5 w-5" />
            ) : (
              <FiMenu className="h-5 w-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="border-t border-white/10 bg-blue-950/95 px-4 py-3 backdrop-blur-sm md:hidden">
          {user ? (
            <nav className="flex flex-col gap-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      setMenuOpen(false);
                    }}
                    className={`flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition-all ${
                      currentPage === item.id
                        ? "bg-white/15 text-white"
                        : "text-white/70 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    {item.label}
                  </button>
                );
              })}
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-red-300 transition-colors hover:bg-red-500/20 hover:text-red-200"
              >
                <FiLogOut className="h-5 w-5" />
                Sair
              </button>
            </nav>
          ) : (
            <div className="flex flex-col gap-2">
              <button
                onClick={() => {
                  onNavigate("login");
                  setMenuOpen(false);
                }}
                className="rounded-lg bg-white/10 px-4 py-3 text-center text-sm font-medium text-white transition-colors hover:bg-white/20"
              >
                Entrar
              </button>
              <button
                onClick={() => {
                  onNavigate("register");
                  setMenuOpen(false);
                }}
                className="rounded-lg bg-blue-600 px-4 py-3 text-center text-sm font-medium text-white transition-colors hover:bg-blue-500"
              >
                Cadastrar
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}