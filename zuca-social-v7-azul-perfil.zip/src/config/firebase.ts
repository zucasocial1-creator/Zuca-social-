import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCq_cxEyF3fArnM-TSrpfnBXWT9yj7ofYc",
  authDomain: "zuca-social.firebaseapp.com",
  projectId: "zuca-social",
  storageBucket: "zuca-social.firebasestorage.app",
  messagingSenderId: "519157719398",
  appId: "1:519157719398:web:5a39464fc7fe79f5ca68a7",
  measurementId: "G-91EQM8MYXB",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);
