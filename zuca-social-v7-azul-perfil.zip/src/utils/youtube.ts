/**
 * RECURSO TEMPORÁRIO: vídeos do YouTube incorporados nas publicações.
 * Quando o Zuca tiver upload de vídeo próprio, este arquivo e o que o usa
 * (FeedPage, campo youtubeId, regra do Firestore) podem ser removidos.
 */

const YT_HOSTS = new Set([
  "youtube.com",
  "www.youtube.com",
  "m.youtube.com",
  "youtu.be",
  "www.youtu.be",
]);

const ID_RE = /^[A-Za-z0-9_-]{11}$/;

export function isValidYouTubeId(id: unknown): id is string {
  return typeof id === "string" && ID_RE.test(id);
}

/** Extrai o ID de um link do YouTube (watch, youtu.be, shorts, embed). Retorna null se não for válido. */
export function extractYouTubeId(raw: string): string | null {
  let url: URL;
  try {
    url = new URL(raw.trim());
  } catch {
    return null;
  }
  if (url.protocol !== "https:" && url.protocol !== "http:") return null;
  if (!YT_HOSTS.has(url.hostname.toLowerCase())) return null;

  let id: string | null = null;
  if (url.hostname.toLowerCase().endsWith("youtu.be")) {
    id = url.pathname.split("/")[1] || null;
  } else if (url.pathname === "/watch") {
    id = url.searchParams.get("v");
  } else {
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts[0] === "shorts" || parts[0] === "embed") id = parts[1] || null;
  }
  return isValidYouTubeId(id) ? id : null;
}
