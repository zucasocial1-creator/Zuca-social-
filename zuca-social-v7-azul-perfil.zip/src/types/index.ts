export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  /** Nome público único, sem o caractere @. */
  username?: string;
  /** true depois que o usuário conclui a configuração inicial do perfil. */
  profileCompleted?: boolean;
  photoURL: string;
  bio: string;
  birthDate: string; // ISO date string
  createdAt: string;
  updatedAt: string;
  isMinor: boolean;
  role: "user" | "moderator" | "admin" | "creator";
  isBlocked: boolean;
  blockedUsers: string[];
  privacyLevel: "public" | "friends" | "private";
  gamification: GamificationData;
  zucaCreator: boolean;
  institutionId?: string;
  /** true para quem tem até 16 anos: conta precisa de autorização do responsável */
  requiresGuardian?: boolean;
  guardianEmail?: string;
}

export type GuardianStatus = "approved" | "pending" | "denied" | "missing";

export interface GuardianRequest {
  minorUid: string;
  minorName: string;
  guardianEmail: string;
  status: "pending" | "approved" | "denied";
  createdAt: string;
  updatedAt: string;
  decidedAt?: string;
  decidedBy?: string;
  /** Limite diário definido pelo responsável (30 a 300 min). Sem valor = 300 (5 h). */
  dailyLimitMinutes?: number;
}

export interface GamificationData {
  points: number;
  level: GamificationLevel;
  xp: number;
  xpToNextLevel: number;
  streak: number;
  lastActiveDate: string;
  badges: Badge[];
  completedMissions: string[];
}

export type GamificationLevel =
  | "Bronze"
  | "Prata"
  | "Ouro"
  | "Esmeralda"
  | "Ametista"
  | "Rubi"
  | "Diamante"
  | "Lendário";

export interface Badge {
  id: string;
  name: string;
  icon: string;
  description: string;
  earnedAt: string;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  xpReward: number;
  pointsReward: number;
  type: "daily" | "weekly" | "achievement";
  condition: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  imageUrl?: string;
  /** ID do vídeo do YouTube incorporado (recurso temporário) */
  youtubeId?: string;
  createdAt: string;
  updatedAt: string;
  likes: string[];
  comments: Comment[];
  isReported: boolean;
  isHidden: boolean;
  tags: string[];
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  authorPhoto: string;
  content: string;
  createdAt: string;
  likes: string[];
}

export interface Report {
  id: string;
  reporterId: string;
  targetType: "post" | "comment" | "user";
  targetId: string;
  reason: string;
  details: string;
  status: "pending" | "reviewed" | "resolved" | "dismissed";
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface Institution {
  id: string;
  name: string;
  type: "organization" | "professional" | "educational";
  description: string;
  logoUrl: string;
  website: string;
  email: string;
  phone: string;
  address: string;
  verified: boolean;
  ownerId: string;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  type: "like" | "comment" | "follow" | "badge" | "mission" | "system";
  message: string;
  read: boolean;
  createdAt: string;
  link?: string;
}