import { useState } from "react";
import { FiCalendar, FiAlertCircle, FiMail } from "react-icons/fi";
import { useAuth } from "../contexts/AuthContext";
import { showsGuardianField, guardianErrorMessage } from "../utils/guardian";
import { sanitizeText } from "../utils/sanitize";

interface CompleteProfilePageProps {
  onDone: () => void;
}

export default function CompleteProfilePage({
  onDone,
}: CompleteProfilePageProps) {
  const { completeProfile, leaveSignup } = useAuth();
  const [birthDate, setBirthDate] = useState("");
  const [guardianEmail, setGuardianEmail] = useState("");
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [underAge, setUnderAge] = useState(false);

  const today = new Date().toISOString().split("T")[0];
  const showGuardian = showsGuardianField(birthDate);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!birthDate) {
      setError("Informe sua data de nascimento.");
      return;
    }
    if (!acceptedTerms) {
      setError("Você deve aceitar os termos de uso.");
      return;
    }

    setLoading(true);
    try {
      await completeProfile(
        birthDate,
        showGuardian ? sanitizeText(guardianEmail).toLowerCase() : undefined
      );
      onDone();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "";
      if (msg === "under-13") {
        setUnderAge(true);
      } else if (msg === "invalid-birthdate") {
        setError("Data de nascimento inválida. Confira e tente de novo.");
      } else if (guardianErrorMessage(msg)) {
        setError(guardianErrorMessage(msg));
      } else {
        console.error("Erro ao completar perfil:", err);
        setError("Não foi possível salvar. Tente novamente.");
      }
    } finally {
      setLoading(false);
    }
  };

  if (underAge) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-12">
        <div className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 p-8 text-center shadow-2xl backdrop-blur-sm">
          <h1 className="mb-3 text-xl font-bold text-white">
            Ainda não dá para entrar
          </h1>
          <p className="mb-6 text-sm text-white/60">
            O Zuca Social é para quem tem 13 anos ou mais. Por isso não vamos
            criar sua conta. Obrigado por entender, e volte quando tiver a idade
            mínima!
          </p>
          <button
            onClick={() => leaveSignup(true)}
            className="w-full rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 py-3 font-semibold text-white"
          >
            Entendi
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur-sm">
          <div className="mb-6 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg">
              <span className="text-3xl font-black text-white">Z</span>
            </div>
            <h1 className="text-2xl font-bold text-white">
              Só mais um passo
            </h1>
            <p className="mt-1 text-sm text-white/50">
              Precisamos da sua data de nascimento para deixar sua conta segura.
            </p>
          </div>

          {error && (
            <div className="mb-4 flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
              <FiAlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                Data de nascimento
              </label>
              <div className="relative">
                <FiCalendar className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                <input
                  type="date"
                  value={birthDate}
                  max={today}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white outline-none transition-colors focus:border-blue-500/50 [color-scheme:dark]"
                  required
                />
              </div>
              <p className="mt-1 text-xs text-white/30">
                Você deve ter pelo menos 13 anos. Menores de 18 terão
                privacidade reforçada (LGPD/ECA).
              </p>
            </div>

            {showGuardian && (
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  E-mail do responsável (maior de 18 anos)
                </label>
                <div className="relative">
                  <FiMail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                  <input
                    type="email"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    placeholder="email@do-responsavel.com"
                    className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white outline-none transition-colors focus:border-blue-500/50"
                    required
                  />
                </div>
                <p className="mt-1 text-xs text-white/30">
                  Até 16 anos, a conta precisa da autorização de um responsável.
                  Ele(a) vai criar uma conta no Zuca Social com este e-mail para
                  autorizar você.
                </p>
              </div>
            )}

            <label className="flex items-start gap-2 text-sm text-white/60">
              <input
                type="checkbox"
                checked={acceptedTerms}
                onChange={(e) => setAcceptedTerms(e.target.checked)}
                className="mt-1"
              />
              <span>Li e aceito os Termos de Uso e a Política de Privacidade.</span>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 py-3 font-semibold text-white transition-opacity disabled:opacity-50"
            >
              {loading ? "Salvando..." : "Continuar"}
            </button>

            <button
              type="button"
              onClick={() => leaveSignup(false)}
              className="w-full py-2 text-sm text-white/40 hover:text-white/70"
            >
              Cancelar e sair
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
