import { useState, useEffect } from "react";
import {
  collection,
  query,
  orderBy,
  limit,
  getDocs,
} from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import {
  getLevelIcon,
  getLevelColor,
} from "../utils/gamification";
import type { UserProfile } from "../types";
import { FiAward, FiTrendingUp, FiUsers } from "react-icons/fi";

export default function RankingPage() {
  const { user } = useAuth();
  const [rankings, setRankings] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"points" | "streak">("points");

  useEffect(() => {
    const loadRankings = async () => {
      try {
        const usersRef = collection(db, "users");
        const field =
          activeTab === "points"
            ? "gamification.points"
            : "gamification.streak";
        const q = query(usersRef, orderBy(field, "desc"), limit(50));
        const snapshot = await getDocs(q);

        const ranked: UserProfile[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data() as UserProfile;
          if (!data.isBlocked) {
            ranked.push(data);
          }
        });
        setRankings(ranked);
      } catch (err) {
        console.error("Erro ao carregar ranking:", err);
      }
      setLoading(false);
    };

    loadRankings();
  }, [activeTab]);

  const getRankBadge = (position: number) => {
    if (position === 1) return "🥇";
    if (position === 2) return "🥈";
    if (position === 3) return "🥉";
    return `#${position}`;
  };

  const allLevels = [
    "Bronze",
    "Prata",
    "Ouro",
    "Esmeralda",
    "Ametista",
    "Rubi",
    "Diamante",
    "Lendário",
  ];

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="mb-6">
        <h1 className="flex items-center gap-3 text-2xl font-bold text-white">
          <FiAward className="h-7 w-7 text-amber-400" />
          Ranking Global
        </h1>
        <p className="mt-1 text-sm text-white/50">
          Os membros mais ativos da comunidade Zuca Social
        </p>
      </div>

      {/* Tabs */}
      <div className="mb-6 flex gap-1 rounded-xl border border-white/10 bg-white/5 p-1">
        <button
          onClick={() => setActiveTab("points")}
          className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all ${
            activeTab === "points"
              ? "bg-white/15 text-white"
              : "text-white/50 hover:bg-white/5"
          }`}
        >
          <FiTrendingUp className="h-4 w-4" />
          Por Pontos
        </button>
        <button
          onClick={() => setActiveTab("streak")}
          className={`flex flex-1 items-center justify-center gap-2 rounded-lg py-2.5 text-sm font-medium transition-all ${
            activeTab === "streak"
              ? "bg-white/15 text-white"
              : "text-white/50 hover:bg-white/5"
          }`}
        >
          <span>🔥</span>
          Por Sequência
        </button>
      </div>

      {/* Levels Info */}
      <div className="mb-6 rounded-2xl border border-white/10 bg-white/5 p-4">
        <h2 className="mb-3 text-sm font-semibold text-white/70">
          Sistema de Níveis
        </h2>
        <div className="flex flex-wrap gap-2">
          {allLevels.map((level) => (
            <span
              key={level}
              className={`inline-flex items-center gap-1 rounded-lg bg-gradient-to-r px-3 py-1 text-xs font-medium text-white ${getLevelColor(
                level as UserProfile["gamification"]["level"]
              )}`}
            >
              {getLevelIcon(
                level as UserProfile["gamification"]["level"]
              )}{" "}
              {level}
            </span>
          ))}
        </div>
      </div>

      {/* Rankings */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
        </div>
      ) : rankings.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-12 text-center">
          <FiUsers className="mx-auto mb-3 h-12 w-12 text-white/20" />
          <p className="text-lg text-white/40">
            Nenhum participante ainda.
          </p>
          <p className="mt-2 text-sm text-white/30">
            Comece a interagir para aparecer no ranking!
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {rankings.map((rankedUser, index) => {
            const position = index + 1;
            const isCurrentUser = rankedUser.uid === user?.uid;

            return (
              <div
                key={rankedUser.uid}
                className={`flex items-center gap-4 rounded-xl border p-4 transition-all ${
                  isCurrentUser
                    ? "border-blue-500/30 bg-blue-500/10"
                    : "border-white/10 bg-white/5 hover:bg-white/8"
                } ${position <= 3 ? "border-opacity-50" : ""}`}
              >
                {/* Position */}
                <div
                  className={`flex h-10 w-10 shrink-0 items-center justify-center text-lg font-bold ${
                    position <= 3 ? "text-2xl" : "text-white/50"
                  }`}
                >
                  {getRankBadge(position)}
                </div>

                {/* Avatar */}
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 font-bold text-white">
                  {rankedUser.displayName?.[0]?.toUpperCase() || "U"}
                </div>

                {/* Info */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-semibold text-white">
                      {rankedUser.displayName}
                    </p>
                    {rankedUser.zucaCreator && (
                      <span className="shrink-0 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 px-2 py-0.5 text-[10px] font-bold text-white">
                        ✨
                      </span>
                    )}
                    {isCurrentUser && (
                      <span className="shrink-0 rounded-full bg-blue-500/20 px-2 py-0.5 text-[10px] font-medium text-blue-400">
                        Você
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 flex items-center gap-3 text-xs text-white/50">
                    <span>
                      {getLevelIcon(rankedUser.gamification.level)}{" "}
                      {rankedUser.gamification.level}
                    </span>
                    <span>•</span>
                    <span>
                      {activeTab === "points"
                        ? `${rankedUser.gamification.points} pontos`
                        : `${rankedUser.gamification.streak} dias 🔥`}
                    </span>
                  </div>
                </div>

                {/* Score */}
                <div className="text-right">
                  <p className="text-lg font-bold text-white">
                    {activeTab === "points"
                      ? rankedUser.gamification.points
                      : rankedUser.gamification.streak}
                  </p>
                  <p className="text-xs text-white/40">
                    {activeTab === "points" ? "pts" : "dias"}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Info */}
      <div className="mt-6 rounded-xl border border-white/10 bg-white/5 p-4 text-center">
        <p className="text-xs text-white/40">
          O ranking é atualizado em tempo real. A pontuação é controlada
          pelo servidor para garantir justiça.
        </p>
      </div>
    </div>
  );
}