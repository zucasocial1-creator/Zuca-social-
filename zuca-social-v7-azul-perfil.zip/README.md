# Zuca Social

**A rede social do Brasil — by Nexus Technology**

---

## Visão Geral

Zuca Social é uma rede social completa construída com React, Vite, Tailwind CSS e Firebase. O projeto oferece uma experiência social moderna com gamificação, moderação avançada e conformidade com a legislação brasileira (LGPD, ECA, Marco Civil da Internet).

## Funcionalidades

### ✅ Implementadas

1. **Cadastro** — Nome, e-mail, senha e data de nascimento com validações
2. **Login** — E-mail/senha e Google via Firebase Authentication
3. **Recuperação de senha** — E-mail de redefinição via Firebase
4. **Logout** — Encerramento seguro de sessão
5. **Perfis** — Configuração inicial com nome, @usuário único, bio e foto da conta quando disponível; armazenamento no Firestore com nível e conquistas
6. **Feed** — Publicações em tempo real com likes e comentários
7. **Proteção contra XSS** — DOMPurify em todas as entradas de texto
8. **Regras Firestore** — Segurança por coleção com roles e ownership
9. **Denúncias** — Sistema completo de denúncias e moderação
10. **Bloqueios** — Bloquear/desbloquear usuários
11. **Proteção de menores** — Detecção de idade, privacidade reforçada
12. **Gamificação** — XP, pontos, níveis, missões e sequências
13. **Níveis** — Bronze, Prata, Ouro, Esmeralda, Ametista, Rubi, Diamante, Lendário
14. **Ranking** — Classificação global por pontos e sequência
15. **Instituições** — Páginas para organizações e profissionais
16. **Moderação** — Painel completo para admins e moderadores
17. **Configurações** — Privacidade, segurança, bloqueios e exclusão de conta

### ⚠️ Pendentes (Requerem Backend/Cloud Functions)

- **Pontuação server-side** — Prevenir manipulação client-side
- **Notificações push** — Firebase Cloud Messaging
- **Upload de imagens** — Firebase Storage
- **Busca de usuários** — Algolia ou similar\n- **Upload de avatar próprio** — Firebase Storage (por enquanto, usa foto da conta Google quando disponível ou iniciais)
- **Sistema de amizade/seguidores** — Coleção de relacionamentos
- **Verificação de idade com documento** — Integração com serviço externo
- **Chat em tempo real** — Realtime Database ou Firestore
- **Notificação a responsáveis** — Para menores de 16 anos (LGPD)

## Stack Tecnológica

| Tecnologia | Uso |
|-----------|-----|
| React 19 | UI Framework |
| Vite 7 | Build tool |
| Tailwind CSS 4 | Estilização |
| Firebase Auth | Autenticação |
| Cloud Firestore | Banco de dados |
| DOMPurify | Sanitização de HTML |
| React Icons | Ícones |

## Estrutura do Projeto

```
src/
├── config/
│   └── firebase.ts          # Configuração Firebase
├── contexts/
│   └── AuthContext.tsx       # Contexto de autenticação
├── components/
│   └── layout/
│       └── Header.tsx        # Cabeçalho com navegação
├── pages/
│   ├── HomePage.tsx          # Landing page
│   ├── LoginPage.tsx         # Login e recuperação de senha
│   ├── RegisterPage.tsx      # Cadastro
│   ├── FeedPage.tsx          # Feed de publicações
│   ├── ProfilePage.tsx       # Perfil e gamificação
│   ├── SettingsPage.tsx      # Configurações
│   ├── RankingPage.tsx       # Ranking global
│   ├── InstitutionsPage.tsx  # Páginas institucionais
│   └── ModerationPage.tsx    # Painel de moderação
├── types/
│   └── index.ts              # Tipos TypeScript
├── utils/
│   ├── sanitize.ts           # Sanitização e validação
│   ├── gamification.ts       # Sistema de níveis e XP
│   └── cn.ts                 # Utilitário Tailwind
├── App.tsx                   # Componente raiz
├── main.tsx                  # Entry point
└── index.css                 # Estilos globais
```

## Início Rápido

```bash
# 1. Instalar dependências
npm install

# 2. Configurar Firebase
# Copie as credenciais do Firebase Console para src/config/firebase.ts
# Ou crie .env.local com VITE_FIREBASE_*

# 3. Executar em desenvolvimento
npm run dev

# 4. Build para produção
npm run build
```

## Identidade visual\n\nA interface usa uma paleta azul-marinho, azul e branco, com componentes responsivos para celular e computador.\n\n## Regras do Firestore

As regras estão em `firestore.rules`. Resumo da proteção:

- **Users**: Dono pode editar perfil; campos protegidos (role, gamification, isBlocked) só via Admin\n- **Usernames**: Reserva de @usuário único em `usernames/{username}`
- **Posts**: Dono pode editar; moderadores podem ocultar; validação de conteúdo
- **Reports**: Qualquer um pode denunciar; só moderadores leem/atualizam
- **Institutions**: Criação livre; verificação manual por admin

## Conformidade Legal

### LGPD
- Consentimento explícito no cadastro
- Dados de menores com proteção reforçada
- Direito ao esquecimento (exclusão de conta)
- Não compartilhamento com terceiros

### ECA
- Idade mínima: 13 anos
- Menores: perfil privado por padrão
- Moderação prioritária para conteúdo de menores

## Licença

© 2024 Nexus Technology. Todos os direitos reservados.