import DOMPurify from "dompurify";

/**
 * Sanitiza texto removendo qualquer HTML/scripts maliciosos.
 * Usar em TODA entrada de texto antes de salvar ou exibir.
 */
export function sanitizeText(text: string): string {
  return DOMPurify.sanitize(text, {
    ALLOWED_TAGS: [],
    ALLOWED_ATTR: [],
  }).trim();
}

/**
 * Sanitiza HTML permitindo apenas formatação básica.
 */
export function sanitizeHTML(html: string): string {
  return DOMPurify.sanitize(html, {
    ALLOWED_TAGS: ["b", "i", "em", "strong", "br", "p"],
    ALLOWED_ATTR: [],
  });
}

/**
 * Valida formato de e-mail.
 */
export function isValidEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

/**
 * Valida força da senha (mínimo 8 caracteres, maiúscula, minúscula, número).
 */
export function isStrongPassword(password: string): boolean {
  return (
    password.length >= 8 &&
    /[A-Z]/.test(password) &&
    /[a-z]/.test(password) &&
    /[0-9]/.test(password)
  );
}

/**
 * Calcula idade a partir de data de nascimento.
 */
export function calculateAge(birthDate: string): number {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  if (
    monthDiff < 0 ||
    (monthDiff === 0 && today.getDate() < birth.getDate())
  ) {
    age--;
  }
  return age;
}

/**
 * Valida se a data de nascimento indica idade >= 13 anos (LGPD).
 * NOTA: Esta é validação client-side apenas. A idade real
 * deve ser verificada no backend para conformidade legal.
 */
export function isValidBirthDate(birthDate: string): boolean {
  if (!birthDate) return false;
  const age = calculateAge(birthDate);
  const today = new Date();
  const birth = new Date(birthDate);
  return age >= 13 && birth < today;
}