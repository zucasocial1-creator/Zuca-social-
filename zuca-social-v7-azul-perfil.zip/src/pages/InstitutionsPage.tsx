import { useState, useEffect } from "react";
import {
  collection,
  query,
  where,
  getDocs,
  addDoc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import { sanitizeText, isValidEmail } from "../utils/sanitize";
import type { Institution } from "../types";
import {
  FiBookOpen,
  FiGlobe,
  FiMail,
  FiPhone,
  FiMapPin,
  FiCheckCircle,
  FiPlus,
  FiAlertCircle,
  FiBriefcase,
  FiUsers,
} from "react-icons/fi";

export default function InstitutionsPage() {
  const { user, profile } = useAuth();
  const [institutions, setInstitutions] = useState<Institution[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [activeFilter, setActiveFilter] = useState<string>("all");

  // Form state
  const [formName, setFormName] = useState("");
  const [formType, setFormType] = useState<
    "organization" | "professional" | "educational"
  >("organization");
  const [formDescription, setFormDescription] = useState("");
  const [formWebsite, setFormWebsite] = useState("");
  const [formEmail, setFormEmail] = useState("");
  const [formPhone, setFormPhone] = useState("");
  const [formAddress, setFormAddress] = useState("");

  useEffect(() => {
    const loadInstitutions = async () => {
      try {
        const instRef = collection(db, "institutions");
        const q = query(instRef, where("verified", "==", true));
        const snapshot = await getDocs(q);

        const insts: Institution[] = [];
        snapshot.forEach((doc) => {
          insts.push({ id: doc.id, ...doc.data() } as Institution);
        });
        setInstitutions(insts);
      } catch (err) {
        console.error("Erro ao carregar instituições:", err);
      }
      setLoading(false);
    };

    loadInstitutions();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!user || !profile) {
      setError("Você precisa estar logado.");
      return;
    }

    const name = sanitizeText(formName);
    const description = sanitizeText(formDescription);
    const email = sanitizeText(formEmail);
    const phone = sanitizeText(formPhone);
    const address = sanitizeText(formAddress);
    const website = sanitizeText(formWebsite);

    if (name.length < 3) {
      setError("O nome deve ter pelo menos 3 caracteres.");
      return;
    }
    if (description.length < 20) {
      setError("A descrição deve ter pelo menos 20 caracteres.");
      return;
    }
    if (!isValidEmail(email)) {
      setError("E-mail inválido.");
      return;
    }

    try {
      await addDoc(collection(db, "institutions"), {
        name,
        type: formType,
        description,
        logoUrl: "",
        website,
        email,
        phone,
        address,
        verified: false, // Requires admin verification
        ownerId: user.uid,
        createdAt: serverTimestamp(),
      });

      setSuccess(
        "Solicitação enviada! Sua página será analisada pela equipe de moderação."
      );
      setShowForm(false);
      setFormName("");
      setFormDescription("");
      setFormWebsite("");
      setFormEmail("");
      setFormPhone("");
      setFormAddress("");
    } catch (err) {
      console.error("Erro ao enviar:", err);
      setError("Erro ao enviar solicitação.");
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "organization":
        return <FiBriefcase className="h-5 w-5" />;
      case "professional":
        return <FiUsers className="h-5 w-5" />;
      case "educational":
        return <FiBookOpen className="h-5 w-5" />;
      default:
        return <FiBriefcase className="h-5 w-5" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "organization":
        return "Organização";
      case "professional":
        return "Profissional";
      case "educational":
        return "Educacional";
      default:
        return type;
    }
  };

  const filteredInstitutions =
    activeFilter === "all"
      ? institutions
      : institutions.filter((inst) => inst.type === activeFilter);

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="flex items-center gap-3 text-2xl font-bold text-white">
            <FiBookOpen className="h-7 w-7 text-blue-400" />
            Instituições & Profissionais
          </h1>
          <p className="mt-1 text-sm text-white/50">
            Páginas verificadas de organizações e profissionais
          </p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-blue-500"
        >
          <FiPlus className="h-4 w-4" />
          Criar Página
        </button>
      </div>

      {/* Status Messages */}
      {success && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-blue-500/30 bg-blue-500/10 px-4 py-3 text-sm text-blue-300">
          <FiCheckCircle className="h-4 w-4" />
          {success}
        </div>
      )}
      {error && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          <FiAlertCircle className="h-4 w-4" />
          {error}
        </div>
      )}

      {/* Create Form */}
      {showForm && (
        <div className="mb-6 rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
          <h2 className="mb-4 text-lg font-semibold text-white">
            Criar Página Institucional
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Nome da Instituição
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  placeholder="Nome da empresa, ONG, etc."
                  required
                  maxLength={100}
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Tipo
                </label>
                <select
                  value={formType}
                  onChange={(e) =>
                    setFormType(
                      e.target.value as
                        | "organization"
                        | "professional"
                        | "educational"
                    )
                  }
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white outline-none focus:border-blue-500/50"
                >
                  <option value="organization">Organização</option>
                  <option value="professional">Profissional</option>
                  <option value="educational">Educacional</option>
                </select>
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                Descrição
              </label>
              <textarea
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                className="w-full resize-none rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                rows={3}
                placeholder="Descreva sua instituição..."
                maxLength={1000}
                required
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  E-mail institucional
                </label>
                <input
                  type="email"
                  value={formEmail}
                  onChange={(e) => setFormEmail(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  placeholder="contato@empresa.com"
                  required
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Telefone
                </label>
                <input
                  type="tel"
                  value={formPhone}
                  onChange={(e) => setFormPhone(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  placeholder="(11) 99999-9999"
                />
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Website
                </label>
                <input
                  type="url"
                  value={formWebsite}
                  onChange={(e) => setFormWebsite(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  placeholder="https://..."
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Endereço
                </label>
                <input
                  type="text"
                  value={formAddress}
                  onChange={(e) => setFormAddress(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  placeholder="Cidade, Estado"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={() => setShowForm(false)}
                className="flex-1 rounded-xl border border-white/10 py-3 text-sm font-medium text-white/70 hover:bg-white/5"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 rounded-xl bg-blue-600 py-3 text-sm font-bold text-white hover:bg-blue-500"
              >
                Enviar para Análise
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filters */}
      <div className="mb-6 flex gap-2 overflow-x-auto">
        {[
          { id: "all", label: "Todas", icon: FiBookOpen },
          { id: "organization", label: "Organizações", icon: FiBriefcase },
          { id: "professional", label: "Profissionais", icon: FiUsers },
          { id: "educational", label: "Educacional", icon: FiBookOpen },
        ].map((filter) => {
          const Icon = filter.icon;
          return (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`flex items-center gap-1.5 whitespace-nowrap rounded-lg px-3 py-2 text-sm font-medium transition-all ${
                activeFilter === filter.id
                  ? "bg-blue-600 text-white"
                  : "border border-white/10 text-white/50 hover:bg-white/5"
              }`}
            >
              <Icon className="h-4 w-4" />
              {filter.label}
            </button>
          );
        })}
      </div>

      {/* Institutions List */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
        </div>
      ) : filteredInstitutions.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-12 text-center">
          <FiBookOpen className="mx-auto mb-3 h-12 w-12 text-white/20" />
          <p className="text-lg text-white/40">
            Nenhuma instituição encontrada.
          </p>
          <p className="mt-2 text-sm text-white/30">
            Seja o primeiro a criar uma página institucional!
          </p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {filteredInstitutions.map((inst) => (
            <div
              key={inst.id}
              className="group rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition-all hover:border-blue-500/30 hover:bg-white/8"
            >
              <div className="mb-3 flex items-start justify-between">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 text-white shadow-lg shadow-blue-500/20">
                  {getTypeIcon(inst.type)}
                </div>
                {inst.verified && (
                  <span className="flex items-center gap-1 rounded-full bg-blue-500/20 px-2 py-0.5 text-xs font-medium text-blue-400">
                    <FiCheckCircle className="h-3 w-3" />
                    Verificada
                  </span>
                )}
              </div>

              <h3 className="text-lg font-bold text-white">{inst.name}</h3>
              <span className="text-xs text-white/40">
                {getTypeLabel(inst.type)}
              </span>

              <p className="mt-2 line-clamp-3 text-sm text-white/60">
                {inst.description}
              </p>

              <div className="mt-4 space-y-1.5 text-xs text-white/40">
                {inst.website && (
                  <p className="flex items-center gap-1.5">
                    <FiGlobe className="h-3.5 w-3.5" />
                    {inst.website}
                  </p>
                )}
                {inst.email && (
                  <p className="flex items-center gap-1.5">
                    <FiMail className="h-3.5 w-3.5" />
                    {inst.email}
                  </p>
                )}
                {inst.phone && (
                  <p className="flex items-center gap-1.5">
                    <FiPhone className="h-3.5 w-3.5" />
                    {inst.phone}
                  </p>
                )}
                {inst.address && (
                  <p className="flex items-center gap-1.5">
                    <FiMapPin className="h-3.5 w-3.5" />
                    {inst.address}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}