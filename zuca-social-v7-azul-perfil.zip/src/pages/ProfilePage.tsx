import { useState, useEffect } from "react";
import {
  doc,
  getDoc,
  updateDoc,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
} from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import { sanitizeText } from "../utils/sanitize";
import { getLevelIcon, getLevelColor } from "../utils/gamification";
import type { UserProfile, Post } from "../types";
import {
  FiEdit3,
  FiSave,
  FiX,
  FiCalendar,
  FiMapPin,
  FiStar,
  FiTrendingUp,
  FiTarget,
} from "react-icons/fi";

interface ProfilePageProps {
  userId?: string;
  onNavigate: (page: string) => void;
}

export default function ProfilePage({ userId, onNavigate }: ProfilePageProps) {
  const { user, profile, refreshProfile } = useAuth();
  const [viewedProfile, setViewedProfile] = useState<UserProfile | null>(null);
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [editing, setEditing] = useState(false);
  const [editBio, setEditBio] = useState("");
  const [editName, setEditName] = useState("");
  const [loading, setLoading] = useState(true);

  const targetUserId = userId || user?.uid;
  const isOwnProfile = targetUserId === user?.uid;

  useEffect(() => {
    if (!targetUserId) return;

    const loadProfile = async () => {
      try {
        if (isOwnProfile && profile) {
          setViewedProfile(profile);
        } else {
          const snap = await getDoc(doc(db, "users", targetUserId));
          if (snap.exists()) {
            setViewedProfile(snap.data() as UserProfile);
          }
        }
      } catch (err) {
        console.error("Erro ao carregar perfil:", err);
      }
      setLoading(false);
    };

    loadProfile();
  }, [targetUserId, profile, isOwnProfile]);

  // Load user posts
  useEffect(() => {
    if (!targetUserId) return;

    const postsRef = collection(db, "posts");
    const q = query(
      postsRef,
      where("authorId", "==", targetUserId),
      where("isHidden", "==", false),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const posts: Post[] = [];
      snapshot.forEach((doc) => {
        posts.push({ id: doc.id, ...doc.data() } as Post);
      });
      setUserPosts(posts);
    });

    return () => unsubscribe();
  }, [targetUserId]);

  const handleSaveProfile = async () => {
    if (!user || !viewedProfile) return;
    const cleanBio = sanitizeText(editBio);
    const cleanName = sanitizeText(editName);

    if (cleanName.length < 3) return;

    try {
      await updateDoc(doc(db, "users", user.uid), {
        displayName: cleanName,
        bio: cleanBio,
        updatedAt: new Date().toISOString(),
      });
      await refreshProfile();
      setEditing(false);
    } catch (err) {
      console.error("Erro ao salvar perfil:", err);
    }
  };

  const formatTime = (timestamp: unknown) => {
    if (!timestamp) return "";
    const date =
      typeof timestamp === "object" && "toDate" in timestamp
        ? (timestamp as { toDate: () => Date }).toDate()
        : new Date(timestamp as string);
    return date.toLocaleDateString("pt-BR");
  };

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
      </div>
    );
  }

  if (!viewedProfile) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-white/50">Perfil não encontrado.</p>
      </div>
    );
  }

  const gamification = viewedProfile.gamification;

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      {/* Profile Header */}
      <div className="mb-6 rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm overflow-hidden">
        {/* Banner */}
        <div className="h-32 bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900" />

        {/* Profile Info */}
        <div className="relative px-6 pb-6">
          {/* Avatar */}
          <div className="-mt-12 mb-4 flex items-end justify-between">
            <div className="flex h-24 w-24 items-center justify-center rounded-2xl border-4 border-gray-900 bg-gradient-to-br from-blue-400 to-blue-600 text-3xl font-black text-white shadow-xl">
              {viewedProfile.displayName?.[0]?.toUpperCase() || "U"}
            </div>
            {isOwnProfile && !editing && (
              <button
                onClick={() => {
                  setEditBio(viewedProfile.bio || "");
                  setEditName(viewedProfile.displayName || "");
                  setEditing(true);
                }}
                className="flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2 text-sm font-medium text-white/70 transition-colors hover:bg-white/10"
              >
                <FiEdit3 className="h-4 w-4" />
                Editar perfil
              </button>
            )}
          </div>

          {editing ? (
            /* Edit Form */
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Nome
                </label>
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  maxLength={50}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white outline-none focus:border-blue-500/50"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Bio
                </label>
                <textarea
                  value={editBio}
                  onChange={(e) => setEditBio(e.target.value)}
                  maxLength={300}
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  rows={3}
                  placeholder="Conte um pouco sobre você..."
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setEditing(false)}
                  className="flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2 text-sm text-white/70 hover:bg-white/5"
                >
                  <FiX className="h-4 w-4" />
                  Cancelar
                </button>
                <button
                  onClick={handleSaveProfile}
                  className="flex items-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-500"
                >
                  <FiSave className="h-4 w-4" />
                  Salvar
                </button>
              </div>
            </div>
          ) : (
            /* Display Profile */
            <>
              <div className="flex items-center gap-3">
                <h1 className="text-2xl font-bold text-white">
                  {viewedProfile.displayName}
                </h1>
                {viewedProfile.zucaCreator && (
                  <span className="rounded-full bg-gradient-to-r from-amber-500 to-orange-500 px-2.5 py-0.5 text-xs font-bold text-white">
                    ✨ Creator
                  </span>
                )}
              </div>
              {viewedProfile.username && (
                <p className="mt-1 text-sm font-medium text-blue-300">@{viewedProfile.username}</p>
              )}
              <p className="mt-2 text-white/60">
                {viewedProfile.bio || "Nenhuma bio ainda."}
              </p>
              <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-white/40">
                <span className="flex items-center gap-1">
                  <FiCalendar className="h-4 w-4" />
                  Membro desde {formatTime(viewedProfile.createdAt)}
                </span>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Gamification Card */}
      <div className="mb-6 rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <FiTrendingUp className="h-5 w-5 text-blue-400" />
          Progresso
        </h2>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <div className="rounded-xl bg-white/5 p-3 text-center">
            <p className="text-2xl">{getLevelIcon(gamification.level)}</p>
            <p className="mt-1 text-xs font-medium text-white/60">
              {gamification.level}
            </p>
          </div>
          <div className="rounded-xl bg-white/5 p-3 text-center">
            <p className="text-2xl font-bold text-white">
              {gamification.points}
            </p>
            <p className="mt-1 text-xs text-white/60">Pontos</p>
          </div>
          <div className="rounded-xl bg-white/5 p-3 text-center">
            <p className="text-2xl font-bold text-blue-400">
              {gamification.xp}
            </p>
            <p className="mt-1 text-xs text-white/60">XP</p>
          </div>
          <div className="rounded-xl bg-white/5 p-3 text-center">
            <p className="text-2xl font-bold text-amber-400">
              {gamification.streak}
            </p>
            <p className="mt-1 text-xs text-white/60">🔥 Sequência</p>
          </div>
        </div>

        {/* XP Progress Bar */}
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-white/50">
            <span>Nível atual</span>
            <span>
              {gamification.xp} / {gamification.xpToNextLevel + gamification.xp} XP
            </span>
          </div>
          <div className="mt-1.5 h-3 overflow-hidden rounded-full bg-white/10">
            <div
              className={`h-full rounded-full bg-gradient-to-r ${getLevelColor(
                gamification.level
              )} transition-all duration-500`}
              style={{
                width: `${Math.min(
                  (gamification.xp /
                    (gamification.xpToNextLevel + gamification.xp)) *
                    100,
                  100
                )}%`,
              }}
            />
          </div>
        </div>

        {/* Badges */}
        {gamification.badges.length > 0 && (
          <div className="mt-4">
            <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-white/70">
              <FiStar className="h-4 w-4" />
              Conquistas
            </h3>
            <div className="flex flex-wrap gap-2">
              {gamification.badges.map((badge) => (
                <div
                  key={badge.id}
                  title={badge.description}
                  className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-sm"
                >
                  <span>{badge.icon}</span>
                  <span className="text-white/70">{badge.name}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Missions */}
        <div className="mt-4">
          <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-white/70">
            <FiTarget className="h-4 w-4" />
            Missões Disponíveis
          </h3>
          <div className="space-y-2">
            {[
              {
                id: "first-post",
                title: "Primeira Publicação",
                desc: "Faça sua primeira publicação no Zuca Social",
                xp: 25,
                done: userPosts.length > 0,
              },
              {
                id: "five-posts",
                title: "Ativo na Comunidade",
                desc: "Faça 5 publicações",
                xp: 50,
                done: userPosts.length >= 5,
              },
              {
                id: "complete-profile",
                title: "Perfil Completo",
                desc: "Preencha seu nome e bio",
                xp: 20,
                done:
                  !!viewedProfile.displayName && !!viewedProfile.bio,
              },
              {
                id: "social-butterfly",
                title: "Borboleta Social",
                desc: "Receba 10 curtidas em suas publicações",
                xp: 100,
                done: false,
              },
            ].map((mission) => (
              <div
                key={mission.id}
                className={`flex items-center justify-between rounded-xl border p-3 ${
                  mission.done
                    ? "border-blue-500/30 bg-blue-500/10"
                    : "border-white/10 bg-white/5"
                }`}
              >
                <div>
                  <p
                    className={`text-sm font-medium ${
                      mission.done ? "text-blue-400" : "text-white/70"
                    }`}
                  >
                    {mission.done ? "✅" : "🎯"} {mission.title}
                  </p>
                  <p className="text-xs text-white/40">{mission.desc}</p>
                </div>
                <span className="text-xs font-medium text-amber-400">
                  +{mission.xp} XP
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* User Posts */}
      <div>
        <h2 className="mb-4 flex items-center gap-2 text-lg font-bold text-white">
          <FiMapPin className="h-5 w-5 text-blue-400" />
          Publicações ({userPosts.length})
        </h2>
        {userPosts.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-center">
            <p className="text-white/40">Nenhuma publicação ainda.</p>
          </div>
        )}
        <div className="space-y-4">
          {userPosts.map((post) => (
            <div
              key={post.id}
              className="rounded-2xl border border-white/10 bg-white/5 p-4"
            >
              <p className="whitespace-pre-wrap text-white/80">
                {post.content}
              </p>
              <div className="mt-3 flex items-center gap-4 text-xs text-white/40">
                <span>{formatTime(post.createdAt)}</span>
                <span>❤️ {post.likes.length}</span>
                <span>💬 {post.comments.length}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Back to Feed */}
      <div className="mt-6 text-center">
        <button
          onClick={() => onNavigate("feed")}
          className="rounded-xl border border-white/10 px-6 py-2 text-sm text-white/60 transition-colors hover:bg-white/5"
        >
          ← Voltar ao Feed
        </button>
      </div>
    </div>
  );
}