import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import { isValidEmail, sanitizeText } from "../utils/sanitize";
import { FcGoogle } from "react-icons/fc";
import { FiMail, FiLock, FiAlertCircle, FiCheckCircle } from "react-icons/fi";

interface LoginPageProps {
  onNavigate: (page: string) => void;
}

export default function LoginPage({ onNavigate }: LoginPageProps) {
  const { login, loginWithGoogle, resetPassword } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [resetEmail, setResetEmail] = useState("");

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const cleanEmail = sanitizeText(email).toLowerCase();
    if (!isValidEmail(cleanEmail)) {
      setError("E-mail inválido.");
      return;
    }
    if (!password) {
      setError("Informe sua senha.");
      return;
    }

    setLoading(true);
    try {
      await login(cleanEmail, password);
      onNavigate("feed");
    } catch (err: unknown) {
      const msg =
        err instanceof Error ? err.message : "Erro ao fazer login.";
      if (msg.includes("user-not-found")) {
        setError("Usuário não encontrado.");
      } else if (msg.includes("wrong-password")) {
        setError("Senha incorreta.");
      } else if (msg.includes("too-many-requests")) {
        setError("Muitas tentativas. Tente novamente mais tarde.");
      } else {
        setError("Erro ao fazer login. Verifique suas credenciais.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError("");
    setLoading(true);
    try {
      await loginWithGoogle();
      onNavigate("feed");
    } catch (err: unknown) {
      const code = (err as { code?: string })?.code || "";
      console.error("Google login:", err);
      if (
        code === "auth/popup-closed-by-user" ||
        code === "auth/cancelled-popup-request"
      ) {
        setError("Login cancelado.");
      } else if (code === "auth/popup-blocked") {
        setError(
          "O navegador bloqueou a janela do Google. Permita pop-ups e tente de novo."
        );
      } else {
        setError(`Erro ao fazer login com Google (${code || "desconhecido"}).`);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    const cleanEmail = sanitizeText(resetEmail).toLowerCase();
    if (!isValidEmail(cleanEmail)) {
      setError("Informe um e-mail válido.");
      return;
    }

    setLoading(true);
    try {
      await resetPassword(cleanEmail);
      setSuccess("E-mail de recuperação enviado! Verifique sua caixa de entrada.");
      setShowReset(false);
    } catch {
      setError("Erro ao enviar e-mail de recuperação.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-64px)] items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur-sm">
          {/* Header */}
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg">
              <span className="text-3xl font-black text-white">Z</span>
            </div>
            <h2 className="text-2xl font-bold text-white">
              Entrar no Zuca Social
            </h2>
            <p className="mt-1 text-sm text-white/50">
              Bem-vindo de volta!
            </p>
          </div>

          {/* Error/Success Messages */}
          {error && (
            <div className="mb-4 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
              <FiAlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}
          {success && (
            <div className="mb-4 flex items-center gap-2 rounded-lg border border-blue-500/30 bg-blue-500/10 px-4 py-3 text-sm text-blue-300">
              <FiCheckCircle className="h-4 w-4 shrink-0" />
              {success}
            </div>
          )}

          {showReset ? (
            /* Password Reset Form */
            <form onSubmit={handleResetPassword} className="space-y-4">
              <p className="text-sm text-white/60">
                Informe seu e-mail para receber o link de recuperação.
              </p>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  E-mail
                </label>
                <div className="relative">
                  <FiMail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                  <input
                    type="email"
                    value={resetEmail}
                    onChange={(e) => setResetEmail(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                    placeholder="seu@email.com"
                    required
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setShowReset(false)}
                  className="flex-1 rounded-xl border border-white/10 py-3 text-sm font-medium text-white/70 transition-colors hover:bg-white/5"
                >
                  Voltar
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 py-3 text-sm font-bold text-white transition-all hover:from-blue-500 hover:to-blue-400 disabled:opacity-50"
                >
                  {loading ? "Enviando..." : "Enviar"}
                </button>
              </div>
            </form>
          ) : (
            /* Login Form */
            <>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="mb-1.5 block text-sm font-medium text-white/70">
                    E-mail
                  </label>
                  <div className="relative">
                    <FiMail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                      placeholder="seu@email.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="mb-1.5 block text-sm font-medium text-white/70">
                    Senha
                  </label>
                  <div className="relative">
                    <FiLock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>

                <div className="text-right">
                  <button
                    type="button"
                    onClick={() => setShowReset(true)}
                    className="text-sm text-blue-400 hover:text-blue-300"
                  >
                    Esqueceu a senha?
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 py-3.5 font-bold text-white shadow-lg shadow-blue-500/20 transition-all hover:from-blue-500 hover:to-blue-400 hover:shadow-xl disabled:opacity-50"
                >
                  {loading ? "Entrando..." : "Entrar"}
                </button>
              </form>

              {/* Divider */}
              <div className="my-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-white/10" />
                <span className="text-xs text-white/30">ou</span>
                <div className="h-px flex-1 bg-white/10" />
              </div>

              {/* Google Login */}
              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="flex w-full items-center justify-center gap-3 rounded-xl border border-white/10 bg-white/5 py-3.5 font-medium text-white transition-all hover:bg-white/10 disabled:opacity-50"
              >
                <FcGoogle className="h-5 w-5" />
                Entrar com Google
              </button>

              {/* Register Link */}
              <p className="mt-6 text-center text-sm text-white/50">
                Não tem conta?{" "}
                <button
                  onClick={() => onNavigate("register")}
                  className="font-medium text-blue-400 hover:text-blue-300"
                >
                  Cadastre-se
                </button>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}