import { useState } from "react";
import { doc, updateDoc, deleteDoc } from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import { sanitizeText } from "../utils/sanitize";
import {
  FiLock,
  FiShield,
  FiEye,
  FiTrash2,
  FiAlertCircle,
  FiCheckCircle,
} from "react-icons/fi";

interface SettingsPageProps {
  onNavigate: (page: string) => void;
}

export default function SettingsPage({ onNavigate }: SettingsPageProps) {
  const { user, profile, logout, refreshProfile } = useAuth();
  const [activeTab, setActiveTab] = useState("privacy");
  const [privacyLevel, setPrivacyLevel] = useState(
    profile?.privacyLevel || "public"
  );
  const [blockUserInput, setBlockUserInput] = useState("");
  const [success, setSuccess] = useState("");
  const [error, setError] = useState("");

  const tabs = [
    { id: "privacy", label: "Privacidade", icon: FiEye },
    { id: "security", label: "Segurança", icon: FiLock },
    { id: "blocked", label: "Bloqueados", icon: FiShield },
    { id: "danger", label: "Zona de Perigo", icon: FiTrash2 },
  ];

  const handleUpdatePrivacy = async () => {
    if (!user) return;
    try {
      await updateDoc(doc(db, "users", user.uid), {
        privacyLevel,
        updatedAt: new Date().toISOString(),
      });
      await refreshProfile();
      setSuccess("Configurações de privacidade atualizadas.");
      setError("");
    } catch {
      setError("Erro ao atualizar privacidade.");
      setSuccess("");
    }
  };

  const handleBlockUser = async () => {
    if (!user || !profile) return;
    const blockId = sanitizeText(blockUserInput);
    if (!blockId) return;

    if (blockId === user.uid) {
      setError("Você não pode bloquear a si mesmo.");
      return;
    }

    try {
      const blockedUsers = [...(profile.blockedUsers || [])];
      if (!blockedUsers.includes(blockId)) {
        blockedUsers.push(blockId);
        await updateDoc(doc(db, "users", user.uid), {
          blockedUsers,
          updatedAt: new Date().toISOString(),
        });
        await refreshProfile();
        setSuccess("Usuário bloqueado.");
      } else {
        setError("Este usuário já está bloqueado.");
      }
      setBlockUserInput("");
    } catch {
      setError("Erro ao bloquear usuário.");
    }
  };

  const handleUnblockUser = async (unblockId: string) => {
    if (!user || !profile) return;
    try {
      const blockedUsers = (profile.blockedUsers || []).filter(
        (id) => id !== unblockId
      );
      await updateDoc(doc(db, "users", user.uid), {
        blockedUsers,
        updatedAt: new Date().toISOString(),
      });
      await refreshProfile();
      setSuccess("Usuário desbloqueado.");
    } catch {
      setError("Erro ao desbloquear usuário.");
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    const confirmed = window.confirm(
      "ATENÇÃO: Esta ação é irreversível. Todos os seus dados serão excluídos. Deseja continuar?"
    );
    if (!confirmed) return;

    const doubleConfirm = window.confirm(
      "Tem certeza absoluta? Digite 'EXCLUIR' mentalmente e clique OK."
    );
    if (!doubleConfirm) return;

    try {
      await deleteDoc(doc(db, "users", user.uid));
      await logout();
      onNavigate("home");
    } catch {
      setError("Erro ao excluir conta. Contate o suporte.");
    }
  };

  if (!user || !profile) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-white/50">Faça login para acessar as configurações.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <h1 className="mb-6 text-2xl font-bold text-white">Configurações</h1>

      {/* Tabs */}
      <div className="mb-6 flex gap-1 overflow-x-auto rounded-xl border border-white/10 bg-white/5 p-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-4 py-2.5 text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? "bg-white/15 text-white"
                  : "text-white/50 hover:bg-white/5 hover:text-white/70"
              }`}
            >
              <Icon className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Status Messages */}
      {success && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-blue-500/30 bg-blue-500/10 px-4 py-3 text-sm text-blue-300">
          <FiCheckCircle className="h-4 w-4" />
          {success}
        </div>
      )}
      {error && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
          <FiAlertCircle className="h-4 w-4" />
          {error}
        </div>
      )}

      {/* Privacy Tab */}
      {activeTab === "privacy" && (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
            <FiEye className="h-5 w-5 text-blue-400" />
            Visibilidade do Perfil
          </h2>
          <div className="space-y-3">
            {[
              {
                value: "public",
                label: "Público",
                desc: "Qualquer pessoa pode ver seu perfil e publicações.",
              },
              {
                value: "friends",
                label: "Amigos",
                desc: "Apenas seus amigos podem ver suas publicações.",
              },
              {
                value: "private",
                label: "Privado",
                desc: "Apenas você pode ver suas publicações.",
              },
            ].map((option) => (
              <label
                key={option.value}
                className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 transition-all ${
                  privacyLevel === option.value
                    ? "border-blue-500/50 bg-blue-500/10"
                    : "border-white/10 hover:border-white/20"
                }`}
              >
                <input
                  type="radio"
                  name="privacy"
                  value={option.value}
                  checked={privacyLevel === option.value}
                  onChange={(e) =>
                    setPrivacyLevel(
                      e.target.value as "public" | "friends" | "private"
                    )
                  }
                  className="mt-1"
                />
                <div>
                  <p className="font-medium text-white">{option.label}</p>
                  <p className="text-sm text-white/50">{option.desc}</p>
                </div>
              </label>
            ))}
          </div>
          <button
            onClick={handleUpdatePrivacy}
            className="mt-4 rounded-xl bg-blue-600 px-6 py-2.5 text-sm font-medium text-white hover:bg-blue-500"
          >
            Salvar Privacidade
          </button>

          {profile.isMinor && (
            <div className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-300">
              <p className="font-medium">⚠️ Conta de menor de idade</p>
              <p className="mt-1 text-amber-300/70">
                Conforme a LGPD e o ECA, contas de menores de 18 anos possuem
                privacidade reforçada. Algumas configurações podem ter
                restrições adicionais.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Security Tab */}
      {activeTab === "security" && (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
            <FiLock className="h-5 w-5 text-blue-400" />
            Segurança da Conta
          </h2>
          <div className="space-y-4">
            <div className="rounded-xl border border-white/10 bg-white/5 p-4">
              <p className="font-medium text-white">E-mail</p>
              <p className="text-sm text-white/50">{user.email}</p>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/5 p-4">
              <p className="font-medium text-white">Conta criada em</p>
              <p className="text-sm text-white/50">
                {user.metadata?.creationTime
                  ? new Date(user.metadata.creationTime).toLocaleDateString(
                      "pt-BR"
                    )
                  : "N/A"}
              </p>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/5 p-4">
              <p className="font-medium text-white">Último login</p>
              <p className="text-sm text-white/50">
                {user.metadata?.lastSignInTime
                  ? new Date(
                      user.metadata.lastSignInTime
                    ).toLocaleDateString("pt-BR")
                  : "N/A"}
              </p>
            </div>
          </div>
          <p className="mt-4 text-sm text-white/40">
            Para alterar sua senha, use a opção "Esqueceu a senha?" na tela de
            login.
          </p>
        </div>
      )}

      {/* Blocked Users Tab */}
      {activeTab === "blocked" && (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-white">
            <FiShield className="h-5 w-5 text-blue-400" />
            Usuários Bloqueados
          </h2>
          <div className="mb-4 flex gap-2">
            <input
              type="text"
              value={blockUserInput}
              onChange={(e) => setBlockUserInput(e.target.value)}
              placeholder="ID do usuário para bloquear"
              className="flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-2.5 text-sm text-white placeholder-white/30 outline-none focus:border-blue-500/50"
            />
            <button
              onClick={handleBlockUser}
              className="rounded-xl bg-red-600 px-4 py-2.5 text-sm font-medium text-white hover:bg-red-500"
            >
              Bloquear
            </button>
          </div>
          {(profile.blockedUsers || []).length === 0 ? (
            <p className="text-sm text-white/40">
              Nenhum usuário bloqueado.
            </p>
          ) : (
            <div className="space-y-2">
              {(profile.blockedUsers || []).map((blockedId) => (
                <div
                  key={blockedId}
                  className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 p-3"
                >
                  <span className="text-sm text-white/70">{blockedId}</span>
                  <button
                    onClick={() => handleUnblockUser(blockedId)}
                    className="rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-500"
                  >
                    Desbloquear
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Danger Zone Tab */}
      {activeTab === "danger" && (
        <div className="rounded-2xl border border-red-500/30 bg-red-500/5 p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-red-400">
            <FiTrash2 className="h-5 w-5" />
            Zona de Perigo
          </h2>
          <div className="space-y-4">
            <div className="rounded-xl border border-red-500/20 bg-red-500/5 p-4">
              <h3 className="font-medium text-white">Excluir Conta</h3>
              <p className="mt-1 text-sm text-white/50">
                Esta ação é irreversível. Todos os seus dados, publicações e
                interações serão permanentemente excluídos.
              </p>
              <button
                onClick={handleDeleteAccount}
                className="mt-3 rounded-xl bg-red-600 px-6 py-2.5 text-sm font-bold text-white transition-all hover:bg-red-500"
              >
                Excluir Minha Conta
              </button>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/5 p-4">
              <h3 className="font-medium text-white">Sair da Conta</h3>
              <p className="mt-1 text-sm text-white/50">
                Encerrar sua sessão neste dispositivo.
              </p>
              <button
                onClick={() => {
                  logout();
                  onNavigate("home");
                }}
                className="mt-3 rounded-xl border border-white/10 px-6 py-2.5 text-sm font-medium text-white/70 hover:bg-white/5"
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Back */}
      <div className="mt-6 text-center">
        <button
          onClick={() => onNavigate("feed")}
          className="rounded-xl border border-white/10 px-6 py-2 text-sm text-white/60 transition-colors hover:bg-white/5"
        >
          ← Voltar ao Feed
        </button>
      </div>
    </div>
  );
}