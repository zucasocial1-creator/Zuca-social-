import { useState } from "react";
import { doc, runTransaction } from "firebase/firestore";
import { updateProfile } from "firebase/auth";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import { sanitizeText } from "../utils/sanitize";
import { FiUser, FiAtSign, FiEdit3, FiAlertCircle, FiCheckCircle } from "react-icons/fi";

interface ProfileSetupPageProps {
  onDone: () => void;
}

export default function ProfileSetupPage({ onDone }: ProfileSetupPageProps) {
  const { user, profile, refreshProfile } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.displayName || user?.displayName || "");
  const [username, setUsername] = useState(profile?.username || "");
  const [bio, setBio] = useState(profile?.bio || "");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setError("");

    if (!user || !profile) {
      setError("Não conseguimos carregar sua conta. Saia e entre novamente.");
      return;
    }

    const cleanName = sanitizeText(displayName).trim();
    const cleanUsername = username.trim().toLowerCase().replace(/^@/, "");
    const cleanBio = sanitizeText(bio).trim();

    if (cleanName.length < 3 || cleanName.length > 50) {
      setError("O nome de exibição deve ter entre 3 e 50 caracteres.");
      return;
    }
    if (!/^[a-z0-9_]{3,20}$/.test(cleanUsername)) {
      setError("O @usuário deve ter de 3 a 20 caracteres: letras, números ou sublinhado.");
      return;
    }
    if (cleanBio.length > 160) {
      setError("A biografia pode ter no máximo 160 caracteres.");
      return;
    }

    setLoading(true);
    try {
      const userRef = doc(db, "users", user.uid);
      const usernameRef = doc(db, "usernames", cleanUsername);

      await runTransaction(db, async (transaction) => {
        const [userSnapshot, usernameSnapshot] = await Promise.all([
          transaction.get(userRef),
          transaction.get(usernameRef),
        ]);

        if (!userSnapshot.exists()) {
          throw new Error("profile-missing");
        }
        if (usernameSnapshot.exists() && usernameSnapshot.data().uid !== user.uid) {
          throw new Error("username-taken");
        }

        transaction.set(usernameRef, {
          uid: user.uid,
          username: cleanUsername,
          createdAt: new Date().toISOString(),
        });
        transaction.update(userRef, {
          displayName: cleanName,
          username: cleanUsername,
          bio: cleanBio,
          profileCompleted: true,
          updatedAt: new Date().toISOString(),
        });
      });

      await updateProfile(user, { displayName: cleanName });
      await refreshProfile();
      onDone();
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (message === "username-taken") {
        setError("Esse @usuário já está sendo utilizado. Escolha outro.");
      } else if (message === "profile-missing") {
        setError("O perfil ainda não foi criado. Saia e entre novamente para tentar.");
      } else {
        console.error("Erro ao configurar perfil:", err);
        setError("Não foi possível salvar seu perfil. Confira sua conexão e tente novamente.");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-64px)] items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-10">
      <div className="w-full max-w-xl">
        <div className="mb-6 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg shadow-blue-500/30">
            <span className="text-3xl font-black text-white">Z</span>
          </div>
          <p className="mb-2 text-sm font-semibold uppercase tracking-[0.2em] text-blue-300">
            Bem-vindo ao Zuca Social
          </p>
          <h1 className="text-3xl font-black text-white sm:text-4xl">
            Vamos criar seu perfil
          </h1>
          <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-white/65">
            Personalize sua presença na comunidade. Você poderá editar essas informações depois.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="rounded-2xl border border-blue-400/20 bg-white/5 p-5 shadow-2xl backdrop-blur-sm sm:p-8">
          {error && (
            <div role="alert" className="mb-5 flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-200">
              <FiAlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div className="mb-6 flex items-center gap-4 rounded-xl border border-white/10 bg-white/5 p-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center overflow-hidden rounded-full bg-blue-600 text-xl font-bold text-white">
              {profile?.photoURL || user?.photoURL ? (
                <img
                  src={profile?.photoURL || user?.photoURL || ""}
                  alt="Foto do perfil"
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                (displayName.trim()[0] || "Z").toUpperCase()
              )}
            </div>
            <div>
              <p className="font-semibold text-white">{displayName || "Seu nome"}</p>
              <p className="text-sm text-white/55">@{username || "seu_usuario"}</p>
              <p className="mt-1 text-xs text-blue-200/80">A foto conectada à sua conta será usada, quando disponível.</p>
            </div>
          </div>

          <div className="space-y-5">
            <div>
              <label htmlFor="displayName" className="mb-2 block text-sm font-semibold text-white/85">
                Nome de exibição
              </label>
              <div className="relative">
                <FiUser className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-blue-300" />
                <input
                  id="displayName"
                  value={displayName}
                  onChange={(event) => setDisplayName(event.target.value)}
                  maxLength={50}
                  autoComplete="name"
                  required
                  className="w-full rounded-xl border border-white/15 bg-slate-950/50 py-3 pl-10 pr-4 text-white placeholder-white/35 outline-none transition focus:border-blue-400"
                  placeholder="Como as pessoas vão te conhecer"
                />
              </div>
            </div>

            <div>
              <label htmlFor="username" className="mb-2 block text-sm font-semibold text-white/85">
                Nome de usuário (@)
              </label>
              <div className="relative">
                <FiAtSign className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-blue-300" />
                <input
                  id="username"
                  value={username}
                  onChange={(event) => setUsername(event.target.value.replace(/[^a-zA-Z0-9_@]/g, "").replace(/^@/, ""))}
                  maxLength={20}
                  minLength={3}
                  autoComplete="username"
                  required
                  className="w-full rounded-xl border border-white/15 bg-slate-950/50 py-3 pl-10 pr-4 text-white placeholder-white/35 outline-none transition focus:border-blue-400"
                  placeholder="francisco123"
                />
              </div>
              <p className="mt-1.5 text-xs text-white/45">De 3 a 20 caracteres. Use letras, números e sublinhado. O @usuário deve ser único.</p>
            </div>

            <div>
              <label htmlFor="bio" className="mb-2 block text-sm font-semibold text-white/85">
                Biografia <span className="font-normal text-white/45">(opcional)</span>
              </label>
              <div className="relative">
                <FiEdit3 className="absolute left-3 top-3 h-5 w-5 text-blue-300" />
                <textarea
                  id="bio"
                  value={bio}
                  onChange={(event) => setBio(event.target.value)}
                  maxLength={160}
                  rows={3}
                  className="w-full resize-none rounded-xl border border-white/15 bg-slate-950/50 py-3 pl-10 pr-4 text-white placeholder-white/35 outline-none transition focus:border-blue-400"
                  placeholder="Conte um pouco sobre você..."
                />
              </div>
              <p className="mt-1 text-right text-xs text-white/40">{bio.length}/160</p>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 px-5 py-3.5 font-bold text-white shadow-lg shadow-blue-900/40 transition hover:from-blue-500 hover:to-blue-400 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <FiCheckCircle className="h-5 w-5" />
            {loading ? "Salvando perfil..." : "Salvar e entrar no Zuca Social"}
          </button>
          <p className="mt-4 text-center text-xs leading-5 text-white/45">
            Seu nome de usuário identifica seu perfil. Não informe dados pessoais sensíveis na biografia.
          </p>
        </form>
      </div>
    </div>
  );
}
