import { useState } from "react";
import { useAuth } from "../contexts/AuthContext";
import {
  isValidEmail,
  isStrongPassword,
  isValidBirthDate,
  sanitizeText,
} from "../utils/sanitize";
import { showsGuardianField, guardianErrorMessage } from "../utils/guardian";
import { FcGoogle } from "react-icons/fc";
import {
  FiUser,
  FiMail,
  FiLock,
  FiCalendar,
  FiAlertCircle,
} from "react-icons/fi";

interface RegisterPageProps {
  onNavigate: (page: string) => void;
}

export default function RegisterPage({ onNavigate }: RegisterPageProps) {
  const { register, loginWithGoogle } = useAuth();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [guardianEmail, setGuardianEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(false);

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    // Validações
    const cleanName = sanitizeText(displayName);
    if (cleanName.length < 3) {
      setError("O nome deve ter pelo menos 3 caracteres.");
      return;
    }
    if (cleanName.length > 50) {
      setError("O nome deve ter no máximo 50 caracteres.");
      return;
    }

    const cleanEmail = sanitizeText(email).toLowerCase();
    if (!isValidEmail(cleanEmail)) {
      setError("E-mail inválido.");
      return;
    }

    if (!isStrongPassword(password)) {
      setError(
        "A senha deve ter pelo menos 8 caracteres, com maiúscula, minúscula e número."
      );
      return;
    }

    if (password !== confirmPassword) {
      setError("As senhas não coincidem.");
      return;
    }

    if (!isValidBirthDate(birthDate)) {
      setError(
        "Data de nascimento inválida. Você deve ter pelo menos 13 anos."
      );
      return;
    }

    const showGuardian = showsGuardianField(birthDate);
    const cleanGuardian = sanitizeText(guardianEmail).toLowerCase();
    if (showGuardian && !isValidEmail(cleanGuardian)) {
      setError("Informe o e-mail do seu responsável (maior de 18 anos).");
      return;
    }

    if (!acceptedTerms) {
      setError("Você deve aceitar os termos de uso.");
      return;
    }

    setLoading(true);
    try {
      await register(
        cleanEmail,
        password,
        cleanName,
        birthDate,
        showGuardian ? cleanGuardian : undefined
      );
      onNavigate("feed");
    } catch (err: unknown) {
      const msg =
        err instanceof Error ? err.message : "Erro ao criar conta.";
      if (msg.includes("email-already-in-use")) {
        setError("Este e-mail já está em uso.");
      } else if (msg.includes("weak-password")) {
        setError("Senha muito fraca.");
      } else if (guardianErrorMessage(msg)) {
        setError(guardianErrorMessage(msg));
      } else {
        setError("Erro ao criar conta. Tente novamente.");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleRegister = async () => {
    if (!acceptedTerms) {
      setError("Você deve aceitar os termos de uso.");
      return;
    }
    setError("");
    setLoading(true);
    try {
      await loginWithGoogle();
      onNavigate("feed");
    } catch (err: unknown) {
      const code = (err as { code?: string })?.code || "";
      console.error("Google register:", err);
      if (
        code === "auth/popup-closed-by-user" ||
        code === "auth/cancelled-popup-request"
      ) {
        setError("Cadastro cancelado.");
      } else if (code === "auth/popup-blocked") {
        setError(
          "O navegador bloqueou a janela do Google. Permita pop-ups e tente de novo."
        );
      } else {
        setError(`Erro ao cadastrar com Google (${code || "desconhecido"}).`);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-[calc(100vh-64px)] items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur-sm">
          {/* Header */}
          <div className="mb-8 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg">
              <span className="text-3xl font-black text-white">Z</span>
            </div>
            <h2 className="text-2xl font-bold text-white">
              Criar Conta no Zuca Social
            </h2>
            <p className="mt-1 text-sm text-white/50">
              É rápido, fácil e gratuito
            </p>
          </div>

          {/* Error */}
          {error && (
            <div className="mb-4 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
              <FiAlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleRegister} className="space-y-4">
            {/* Name */}
            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                Nome completo
              </label>
              <div className="relative">
                <FiUser className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                  placeholder="Seu nome"
                  maxLength={50}
                  required
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                E-mail
              </label>
              <div className="relative">
                <FiMail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                  placeholder="seu@email.com"
                  required
                />
              </div>
            </div>

            {/* Birth Date */}
            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                Data de nascimento
              </label>
              <div className="relative">
                <FiCalendar className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                <input
                  type="date"
                  value={birthDate}
                  onChange={(e) => setBirthDate(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white outline-none transition-colors focus:border-blue-500/50 [color-scheme:dark]"
                  required
                />
              </div>
              <p className="mt-1 text-xs text-white/30">
                Você deve ter pelo menos 13 anos. Menores de 18 terão privacidade
                reforçada (LGPD/ECA).
              </p>
            </div>

            {showsGuardianField(birthDate) && (
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  E-mail do responsável (maior de 18 anos)
                </label>
                <div className="relative">
                  <FiMail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                  <input
                    type="email"
                    value={guardianEmail}
                    onChange={(e) => setGuardianEmail(e.target.value)}
                    placeholder="email@do-responsavel.com"
                    className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white outline-none transition-colors focus:border-blue-500/50"
                    required
                  />
                </div>
                <p className="mt-1 text-xs text-white/30">
                  Até 16 anos, a conta precisa da autorização de um responsável.
                  Ele(a) vai criar uma conta no Zuca Social com este e-mail para
                  autorizar você.
                </p>
              </div>
            )}

            {/* Password */}
            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                Senha
              </label>
              <div className="relative">
                <FiLock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                  placeholder="••••••••"
                  required
                />
              </div>
              <p className="mt-1 text-xs text-white/30">
                Mínimo 8 caracteres, com maiúscula, minúscula e número.
              </p>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="mb-1.5 block text-sm font-medium text-white/70">
                Confirmar senha
              </label>
              <div className="relative">
                <FiLock className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            {/* Terms */}
            <label className="flex items-start gap-3 text-sm text-white/60">
              <input
                type="checkbox"
                checked={acceptedTerms}
                onChange={(e) => setAcceptedTerms(e.target.checked)}
                className="mt-1 h-4 w-4 rounded border-white/20 bg-white/5 text-blue-500 focus:ring-blue-500"
              />
              <span>
                Li e aceito os{" "}
                <span className="text-blue-400">Termos de Uso</span> e a{" "}
                <span className="text-blue-400">
                  Política de Privacidade
                </span>{" "}
                do Zuca Social.
              </span>
            </label>

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 py-3.5 font-bold text-white shadow-lg shadow-blue-500/20 transition-all hover:from-blue-500 hover:to-blue-400 hover:shadow-xl disabled:opacity-50"
            >
              {loading ? "Criando conta..." : "Criar Conta"}
            </button>
          </form>

          {/* Divider */}
          <div className="my-6 flex items-center gap-3">
            <div className="h-px flex-1 bg-white/10" />
            <span className="text-xs text-white/30">ou</span>
            <div className="h-px flex-1 bg-white/10" />
          </div>

          {/* Google Register */}
          <button
            onClick={handleGoogleRegister}
            disabled={loading}
            className="flex w-full items-center justify-center gap-3 rounded-xl border border-white/10 bg-white/5 py-3.5 font-medium text-white transition-all hover:bg-white/10 disabled:opacity-50"
          >
            <FcGoogle className="h-5 w-5" />
            Cadastrar com Google
          </button>

          <p className="mt-6 text-center text-sm text-white/50">
            Já tem conta?{" "}
            <button
              onClick={() => onNavigate("login")}
              className="font-medium text-blue-400 hover:text-blue-300"
            >
              Entrar
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}