import { useEffect, useRef, useState, type ReactNode } from "react";
import { doc, getDoc, setDoc, increment } from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import {
  DAILY_LIMIT_SECONDS,
  WARNING_SECONDS,
  todayKey,
  formatDuration,
} from "../utils/screenTime";

const TICK_MS = 15_000; // confere a cada 15 segundos
const FLUSH_MS = 60_000; // salva no banco a cada 1 minuto

interface Props {
  children: ReactNode;
}

/**
 * Limita o tempo de uso por dia (contas de 13 a 16 anos já autorizadas).
 * Só conta o tempo em que o app está aberto e visível na tela.
 */
export default function ScreenTimeGuard({ children }: Props) {
  const {
    user,
    profile,
    needsGuardian,
    guardianStatus,
    guardianLimitMinutes,
    syncGuardian,
    logout,
  } = useAuth();
  const uid = user?.uid;
  const enabled = !!uid && !!profile && needsGuardian && guardianStatus === "approved";

  const [used, setUsed] = useState<number | null>(null);

  // O responsável pode diminuir o limite, nunca aumentar acima das 5 horas
  const limitSeconds = Math.min(
    DAILY_LIMIT_SECONDS,
    (guardianLimitMinutes ?? DAILY_LIMIT_SECONDS / 60) * 60
  );

  // A cada 2 minutos confere se o responsável mudou o limite ou revogou a autorização
  const syncRef = useRef(syncGuardian);
  syncRef.current = syncGuardian;
  useEffect(() => {
    if (!enabled) return;
    const id = window.setInterval(() => syncRef.current(), 120_000);
    return () => window.clearInterval(id);
  }, [enabled]);

  useEffect(() => {
    if (!enabled || !uid) {
      setUsed(null);
      return;
    }

    let cancelled = false;
    const ref = doc(db, "screenTime", uid);
    let docDate: string | null = null; // data guardada no banco
    let currentDay = todayKey();
    let pending = 0; // segundos ainda não salvos
    let last = Date.now();
    let lastFlush = Date.now();
    let interval: number | undefined;

    const flush = async () => {
      if (pending < 1) return;
      const delta = Math.round(pending);
      pending = 0;
      lastFlush = Date.now();
      const today = todayKey();
      const updatedAt = new Date().toISOString();
      try {
        if (docDate !== today) {
          // Primeiro registro do dia: começa a contagem do zero
          await setDoc(ref, { date: today, seconds: delta, updatedAt });
          docDate = today;
        } else {
          await setDoc(
            ref,
            { date: today, seconds: increment(delta), updatedAt },
            { merge: true }
          );
        }
      } catch (err) {
        console.error("Erro ao salvar tempo de uso:", err);
        pending += delta; // tenta de novo na próxima
      }
    };

    const tick = () => {
      const now = Date.now();
      // Limita o salto para não contar o tempo em que o aparelho dormiu
      const elapsed = Math.min((now - last) / 1000, (TICK_MS / 1000) * 2);
      last = now;
      if (document.visibilityState !== "visible") return;

      const today = todayKey();
      if (today !== currentDay) {
        currentDay = today; // virou o dia: contagem nova
        setUsed(0);
      }
      pending += elapsed;
      setUsed((u) => (u === null ? u : u + elapsed));
      if (now - lastFlush >= FLUSH_MS) flush();
    };

    const onVisibility = () => {
      if (document.visibilityState === "hidden") flush();
      else last = Date.now();
    };

    (async () => {
      let initial = 0;
      try {
        const snap = await getDoc(ref);
        if (snap.exists()) {
          const data = snap.data() as { date?: string; seconds?: number };
          docDate = data.date || null;
          if (data.date === currentDay) initial = data.seconds || 0;
        }
      } catch (err) {
        console.error("Erro ao ler tempo de uso:", err);
      }
      if (cancelled) return;
      last = Date.now();
      setUsed(initial);
      interval = window.setInterval(tick, TICK_MS);
      document.addEventListener("visibilitychange", onVisibility);
    })();

    return () => {
      cancelled = true;
      if (interval) window.clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisibility);
      flush();
    };
  }, [enabled, uid]);

  if (!enabled) return <>{children}</>;

  if (used === null) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
      </div>
    );
  }

  if (used >= limitSeconds) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-12">
        <div className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 p-8 text-center shadow-2xl backdrop-blur-sm">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg">
            <span className="text-3xl font-black text-white">Z</span>
          </div>
          <h1 className="mb-3 text-xl font-bold text-white">
            Seu tempo de hoje acabou
          </h1>
          <p className="mb-6 text-sm text-white/60">
            Você usou as {formatDuration(limitSeconds)} do Zuca Social de hoje
            {guardianLimitMinutes !== null &&
            guardianLimitMinutes < DAILY_LIMIT_SECONDS / 60
              ? " (tempo combinado com seu responsável)"
              : ""}
            . Que tal aproveitar para estudar, descansar ou conversar com a
            família? Amanhã o tempo volta.
          </p>
          <button
            onClick={logout}
            className="w-full rounded-xl border border-white/10 py-3 text-sm text-white/70"
          >
            Sair
          </button>
        </div>
      </div>
    );
  }

  const remaining = limitSeconds - used;
  return (
    <>
      {remaining <= WARNING_SECONDS && (
        <div className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-full border border-yellow-400/30 bg-yellow-500/20 px-4 py-2 text-xs text-yellow-100 shadow-lg backdrop-blur">
          Faltam {formatDuration(remaining)} do seu tempo de hoje
        </div>
      )}
      {children}
    </>
  );
}
