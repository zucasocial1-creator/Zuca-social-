import { useAuth } from "../contexts/AuthContext";
import {
  FiUsers,
  FiShield,
  FiAward,
  FiTrendingUp,
  FiLock,
  FiHeart,
} from "react-icons/fi";

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const { user } = useAuth();

  const features = [
    {
      icon: FiUsers,
      title: "Conecte-se",
      desc: "Encontre pessoas, compartilhe ideias e faça parte de uma comunidade vibrante.",
    },
    {
      icon: FiShield,
      title: "Seguro & Moderado",
      desc: "Proteção avançada contra conteúdo malicioso e moderação ativa 24/7.",
    },
    {
      icon: FiAward,
      title: "Gamificação",
      desc: "Ganhe XP, suba de nível, desbloqueie conquistas e dispute o ranking.",
    },
    {
      icon: FiTrendingUp,
      title: "Feed Inteligente",
      desc: "Publicações em tempo real com sistema de curtidas e comentários.",
    },
    {
      icon: FiLock,
      title: "Privacidade",
      desc: "Controle total sobre seus dados e quem pode ver seu conteúdo.",
    },
    {
      icon: FiHeart,
      title: "Inclusivo",
      desc: "Ambiente seguro para todas as idades, em conformidade com ECA e LGPD.",
    },
  ];

  const levels = [
    { name: "Bronze", icon: "🥉", color: "from-amber-700 to-amber-500" },
    { name: "Prata", icon: "🥈", color: "from-gray-400 to-gray-300" },
    { name: "Ouro", icon: "🥇", color: "from-yellow-500 to-yellow-300" },
    { name: "Esmeralda", icon: "💎", color: "from-emerald-600 to-emerald-400" },
    { name: "Ametista", icon: "🔮", color: "from-purple-600 to-purple-400" },
    { name: "Rubi", icon: "❤️", color: "from-red-600 to-red-400" },
    { name: "Diamante", icon: "💠", color: "from-cyan-500 to-blue-400" },
    { name: "Lendário", icon: "👑", color: "from-amber-500 via-yellow-400 to-amber-600" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950">
      {/* Hero */}
      <section className="relative overflow-hidden px-4 pb-20 pt-20">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-blue-500 blur-[128px]" />
          <div className="absolute right-1/4 top-1/2 h-96 w-96 rounded-full bg-red-500 blur-[128px]" />
        </div>
        <div className="relative mx-auto max-w-4xl text-center">
          <div className="mb-8 inline-flex h-24 w-24 items-center justify-center rounded-3xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-2xl shadow-blue-500/30">
            <span className="text-5xl font-black text-white">Z</span>
          </div>
          <h1 className="mb-4 text-5xl font-black tracking-tight text-white md:text-7xl">
            Zuca{" "}
            <span className="bg-gradient-to-r from-blue-400 to-blue-300 bg-clip-text text-transparent">
              Social
            </span>
          </h1>
          <p className="mb-2 text-xl text-white/70 md:text-2xl">
            A rede social do Brasil
          </p>
          <p className="mb-10 text-sm text-white/40">
            by Nexus Technology
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            {user ? (
              <button
                onClick={() => onNavigate("feed")}
                className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 px-8 py-4 text-lg font-bold text-white shadow-lg shadow-blue-500/30 transition-all hover:scale-105 hover:shadow-xl hover:shadow-blue-500/40"
              >
                Abrir Feed
              </button>
            ) : (
              <>
                <button
                  onClick={() => onNavigate("register")}
                  className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 px-8 py-4 text-lg font-bold text-white shadow-lg shadow-blue-500/30 transition-all hover:scale-105 hover:shadow-xl hover:shadow-blue-500/40"
                >
                  Criar Conta Grátis
                </button>
                <button
                  onClick={() => onNavigate("login")}
                  className="rounded-xl border border-white/20 bg-white/5 px-8 py-4 text-lg font-bold text-white backdrop-blur-sm transition-all hover:bg-white/10"
                >
                  Já tenho conta
                </button>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="px-4 pb-20">
        <div className="mx-auto max-w-6xl">
          <h2 className="mb-12 text-center text-3xl font-bold text-white">
            Por que escolher o Zuca Social?
          </h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div
                  key={i}
                  className="group rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm transition-all hover:border-blue-500/30 hover:bg-white/10"
                >
                  <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-blue-600 to-blue-700 shadow-lg shadow-blue-500/20 transition-transform group-hover:scale-110">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="mb-2 text-lg font-bold text-white">
                    {f.title}
                  </h3>
                  <p className="text-sm text-white/60">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Levels */}
      <section className="px-4 pb-20">
        <div className="mx-auto max-w-4xl">
          <h2 className="mb-4 text-center text-3xl font-bold text-white">
            Sistema de Níveis
          </h2>
          <p className="mb-12 text-center text-white/50">
            Participe, interaja e suba de nível para desbloquear recompensas exclusivas
          </p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            {levels.map((lvl, i) => (
              <div
                key={i}
                className="group flex flex-col items-center rounded-2xl border border-white/10 bg-white/5 p-4 text-center transition-all hover:border-white/20 hover:bg-white/10"
              >
                <span className="mb-2 text-4xl transition-transform group-hover:scale-125">
                  {lvl.icon}
                </span>
                <h3 className="text-sm font-bold text-white">{lvl.name}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="px-4 pb-20">
        <div className="mx-auto max-w-3xl rounded-3xl border border-white/10 bg-gradient-to-r from-blue-900/50 to-blue-900/50 p-12 text-center backdrop-blur-sm">
          <h2 className="mb-4 text-3xl font-bold text-white">
            Pronto para fazer parte?
          </h2>
          <p className="mb-8 text-white/60">
            Junte-se a milhares de brasileiros na rede social que respeita sua
            privacidade e valoriza sua participação.
          </p>
          {!user && (
            <button
              onClick={() => onNavigate("register")}
              className="rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 px-8 py-4 text-lg font-bold text-white shadow-lg shadow-blue-500/30 transition-all hover:scale-105"
            >
              Comece Agora — É Grátis
            </button>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/10 px-4 py-8 text-center">
        <p className="text-sm text-white/30">
          © 2024 Nexus Technology. Todos os direitos reservados.
        </p>
        <p className="mt-2 text-xs text-white/20">
          Zuca Social — Protegido pela LGPD e em conformidade com o ECA.
        </p>
      </footer>
    </div>
  );
}