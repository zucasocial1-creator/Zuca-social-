/** Limite diário de uso do Zuca Social para contas de 13 a 16 anos. */
export const DAILY_LIMIT_SECONDS = 5 * 60 * 60; // 5 horas

/** Avisa quando faltar este tempo para acabar o limite. */
export const WARNING_SECONDS = 15 * 60; // 15 minutos

/** Data de hoje no fuso do aparelho, no formato AAAA-MM-DD. */
export function todayKey(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Ex.: 8100 -> "2h 15min" */
export function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds / 60));
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (h === 0) return `${m}min`;
  return m === 0 ? `${h}h` : `${h}h ${m}min`;
}
