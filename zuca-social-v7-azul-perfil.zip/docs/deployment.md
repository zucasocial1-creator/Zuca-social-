# Zuca Social — Documentação de Implantação

## Nexus Technology

---

## 1. Pré-requisitos

- Node.js 18+ (recomendado: 20 LTS)
- npm ou yarn
- Conta Firebase (Blaze plan para Cloud Functions)
- Firebase CLI instalado: `npm install -g firebase-tools`

## 2. Configuração do Firebase

### 2.1 Criar Projeto

1. Acesse [Firebase Console](https://console.firebase.google.com)
2. Crie um novo projeto ou selecione existente
3. Ative: Authentication, Firestore, Hosting

### 2.2 Authentication

1. Firebase Console > Authentication > Sign-in method
2. Ative: **E-mail/senha** e **Google**
3. Configure domínios autorizados

### 2.3 Firestore

1. Firebase Console > Firestore Database
2. Crie banco em **modo nativo**
3. Selecione região: `southamerica-east1` (São Paulo)
4. Aplique as regras de `firestore.rules`

### 2.4 Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto:

```env
VITE_FIREBASE_API_KEY=sua-api-key
VITE_FIREBASE_AUTH_DOMAIN=seu-projeto.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=seu-projeto
VITE_FIREBASE_STORAGE_BUCKET=seu-projeto.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=000000000000
VITE_FIREBASE_APP_ID=1:000000000000:web:0000000000000000000000
VITE_FIREBASE_MEASUREMENT_ID=G-XXXXXXXXXX
```

## 3. Build e Deploy

### 3.1 Desenvolvimento Local

```bash
npm install
npm run dev
```

### 3.2 Build para Produção

```bash
npm run build
```

### 3.3 Deploy Firebase Hosting

```bash
firebase login
firebase init hosting
firebase deploy
```

## 4. Cloud Functions (Recomendado)

Para operações sensíveis como pontuação, moderação e proteção de menores:

### 4.1 Estrutura Sugerida

```
functions/
├── src/
│   ├── index.ts
│   ├── gamification.ts    # Cálculo server-side de XP/pontos
│   ├── moderation.ts      # Moderação automática
│   ├── notifications.ts   # Sistema de notificações
│   └── ageVerification.ts # Verificação de idade
├── package.json
└── tsconfig.json
```

### 4.2 Exemplo: Gamificação Server-Side

```typescript
// functions/src/gamification.ts
import * as functions from "firebase-functions";
import * as admin from "firebase-admin";

const db = admin.firestore();

// Trigger: quando um post é criado
export const onPostCreated = functions.firestore
  .document("posts/{postId}")
  .onCreate(async (snap, context) => {
    const post = snap.data();
    const userId = post.authorId;

    const userRef = db.collection("users").doc(userId);
    const userSnap = await userRef.get();
    const userData = userSnap.data();

    if (!userData) return;

    const xpGain = 10; // XP por publicação
    const newXP = (userData.gamification?.xp || 0) + xpGain;
    const newPoints = (userData.gamification?.points || 0) + xpGain;

    // Calcular nível
    let level = "Bronze";
    if (newPoints >= 4000) level = "Lendário";
    else if (newPoints >= 2500) level = "Diamante";
    else if (newPoints >= 1600) level = "Rubi";
    else if (newPoints >= 1000) level = "Ametista";
    else if (newPoints >= 600) level = "Esmeralda";
    else if (newPoints >= 300) level = "Ouro";
    else if (newPoints >= 100) level = "Prata";

    await userRef.update({
      "gamification.xp": newXP,
      "gamification.points": newPoints,
      "gamification.level": level,
      "gamification.lastActiveDate": new Date().toISOString().split("T")[0],
    });
  });

// Trigger: quando um like é dado
export const onPostLiked = functions.firestore
  .document("posts/{postId}")
  .onUpdate(async (change, context) => {
    const before = change.before.data();
    const after = change.after.data();

    if (after.likes.length > before.likes.length) {
      // Novo like - dar XP ao autor do post
      const authorId = after.authorId;
      const userRef = db.collection("users").doc(authorId);

      await userRef.update({
        "gamification.xp": admin.firestore.FieldValue.increment(5),
        "gamification.points": admin.firestore.FieldValue.increment(5),
      });
    }
  });
```

## 5. Regras de Segurança

As regras do Firestore estão em `firestore.rules`. Resumo:

| Coleção   | Leitura        | Escrita                    | Notas                    |
|-----------|---------------|----------------------------|--------------------------|
| users     | Autenticado    | Dono do perfil             | Campos protegidos        |
| posts     | Autenticado    | Dono + Mod pode ocultar    | Sanitização obrigatória  |
| reports   | Moderador      | Qualquer (criar)           | Auditoria completa       |
| institutions | Autenticado | Dono + Admin verifica      | Verificação manual       |

## 6. Conformidade Legal

### LGPD (Lei Geral de Proteção de Dados)

- Consentimento explícito no cadastro
- Dados de menores com privacidade reforçada
- Direito ao esquecimento (exclusão de conta)
- DPO (Encarregado) deve ser nomeado

### ECA (Estatuto da Criança e do Adolescente)

- Idade mínima: 13 anos
- Menores de 18: perfil privado por padrão
- Moderação prioritária para conteúdo envolvendo menores
- Notificação aos responsáveis (implementação futura)

### Marco Civil da Internet

- Logs de acesso por 1 ano
- Transparente sobre coleta de dados
- Não compartilhamento com terceiros sem consentimento

## 7. Monitoramento

### Métricas Importantes

- Usuários ativos (DAU/MAU)
- Denúncias pendentes/tempo de resposta
- Taxa de resolução de denúncias
- Erros de autenticação
- Tempo de carregamento do feed

### Ferramentas Recomendadas

- Firebase Analytics
- Firebase Performance Monitoring
- Google Cloud Logging
- Sentry (erros frontend)

## 8. Backup e Recuperação

```bash
# Backup Firestore
gcloud firestore export gs://seu-bucket/backup-$(date +%Y%m%d)

# Agendamento automático (Cloud Scheduler)
gcloud scheduler jobs create http firestore-backup \
  --schedule="0 3 * * *" \
  --uri="https://firestore.googleapis.com/v1/projects/seu-projeto/databases/(default):exportDocuments" \
  --http-method=POST
```

## 9. Checklist de Produção

- [ ] Firebase config via variáveis de ambiente
- [ ] Regras Firestore aplicadas e testadas
- [ ] Cloud Functions para gamificação
- [ ] Backup automático configurado
- [ ] Analytics e monitoring ativos
- [ ] DPO nomeado (LGPD)
- [ ] Termos de uso e política de privacidade publicados
- [ ] SSL/HTTPS ativo
- [ ] Testes de carga realizados
- [ ] Plano de incident response definido