import { calculateAge, isValidBirthDate } from "./sanitize";

/** Contas de até 16 anos precisam estar vinculadas a um responsável legal (ECA Digital, Lei 15.211/2025). */
export const GUARDIAN_MAX_AGE = 16;

/** true se a data de nascimento indica 13 a 16 anos (idade mínima 13 já validada à parte). */
export function needsGuardianFor(birthDate: string | undefined | null): boolean {
  if (!birthDate) return false;
  const birth = new Date(birthDate);
  if (isNaN(birth.getTime())) return false;
  return calculateAge(birthDate) <= GUARDIAN_MAX_AGE;
}

/** true se a data é válida E a pessoa precisa de responsável (13 a 16 anos). */
export function showsGuardianField(birthDate: string): boolean {
  return isValidBirthDate(birthDate) && needsGuardianFor(birthDate);
}

/** Traduz os códigos de erro do e-mail do responsável em mensagem para a tela. */
export function guardianErrorMessage(msg: string): string {
  if (msg.includes("guardian-email-required"))
    return "Informe o e-mail do seu responsável (maior de 18 anos).";
  if (msg.includes("guardian-email-invalid"))
    return "O e-mail do responsável não parece válido.";
  if (msg.includes("guardian-email-same"))
    return "O e-mail do responsável precisa ser diferente do seu.";
  if (msg.includes("request-closed"))
    return "Este pedido já foi respondido pelo responsável.";
  return "";
}
