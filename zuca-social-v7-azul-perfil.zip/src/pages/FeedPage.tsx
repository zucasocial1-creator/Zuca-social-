import { useState, useEffect } from "react";
import {
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  updateDoc,
  doc,
  arrayUnion,
  arrayRemove,
  serverTimestamp,
  limit,
  where,
} from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import { sanitizeText } from "../utils/sanitize";
import { extractYouTubeId, isValidYouTubeId } from "../utils/youtube";
// XP_REWARDS available for server-side scoring
import type { Post } from "../types";
import {
  FiHeart,
  FiMessageCircle,
  FiSend,
  FiImage,
  FiVideo,
  FiMoreHorizontal,
  FiFlag,
  FiTrash2,
  FiAlertCircle,
} from "react-icons/fi";

export default function FeedPage() {
  const { user, profile } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [newPost, setNewPost] = useState("");
  const [videoLink, setVideoLink] = useState("");
  const [showVideoInput, setShowVideoInput] = useState(false);
  const [loading, setLoading] = useState(true);
  const [commentTexts, setCommentTexts] = useState<Record<string, string>>({});
  const [expandedComments, setExpandedComments] = useState<Set<string>>(
    new Set()
  );
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const [reportModal, setReportModal] = useState<{
    type: "post" | "comment";
    id: string;
  } | null>(null);
  const [reportReason, setReportReason] = useState("");
  const [reportDetails, setReportDetails] = useState("");
  const [error, setError] = useState("");

  // Real-time feed listener
  useEffect(() => {
    if (!user) return;

    const postsRef = collection(db, "posts");
    const q = query(
      postsRef,
      where("isHidden", "==", false),
      orderBy("createdAt", "desc"),
      limit(50)
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const feedPosts: Post[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          // Filter out posts from blocked users
          const blockedUsers = profile?.blockedUsers || [];
          if (!blockedUsers.includes(data.authorId)) {
            feedPosts.push({ id: doc.id, ...data } as Post);
          }
        });
        setPosts(feedPosts);
        setLoading(false);
      },
      (err) => {
        console.error("Erro no feed:", err);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [user, profile?.blockedUsers]);

  const handleCreatePost = async () => {
    if (!user || !profile) return;
    const content = sanitizeText(newPost);
    if (!content || content.length < 1) return;
    if (content.length > 2000) {
      setError("Publicação limitada a 2000 caracteres.");
      return;
    }

    // Vídeo do YouTube (recurso temporário)
    let youtubeId: string | null = null;
    const rawLink = videoLink.trim();
    if (rawLink) {
      youtubeId = extractYouTubeId(rawLink);
      if (!youtubeId) {
        setError("Link do YouTube inválido. Cole o link completo do vídeo.");
        return;
      }
    }

    try {
      await addDoc(collection(db, "posts"), {
        authorId: user.uid,
        authorName: profile.displayName,
        authorPhoto: profile.photoURL || "",
        content,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        likes: [],
        comments: [],
        isReported: false,
        isHidden: false,
        tags: [],
        ...(youtubeId ? { youtubeId } : {}),
      });

      setNewPost("");
      setVideoLink("");
      setShowVideoInput(false);
      setError("");
    } catch (err) {
      console.error("Erro ao criar post:", err);
      setError("Erro ao publicar. Tente novamente.");
    }
  };

  const handleLike = async (postId: string) => {
    if (!user) return;
    const postRef = doc(db, "posts", postId);
    const post = posts.find((p) => p.id === postId);
    if (!post) return;

    const isLiked = post.likes.includes(user.uid);
    try {
      await updateDoc(postRef, {
        likes: isLiked ? arrayRemove(user.uid) : arrayUnion(user.uid),
      });
    } catch (err) {
      console.error("Erro ao curtir:", err);
    }
  };

  const handleComment = async (postId: string) => {
    if (!user || !profile) return;
    const text = sanitizeText(commentTexts[postId] || "");
    if (!text) return;
    if (text.length > 500) {
      setError("Comentário limitado a 500 caracteres.");
      return;
    }

    const postRef = doc(db, "posts", postId);
    const comment = {
      id: `${Date.now()}-${user.uid}`,
      authorId: user.uid,
      authorName: profile.displayName,
      authorPhoto: profile.photoURL || "",
      content: text,
      createdAt: new Date().toISOString(),
      likes: [],
    };

    try {
      await updateDoc(postRef, {
        comments: arrayUnion(comment),
      });
      setCommentTexts((prev) => ({ ...prev, [postId]: "" }));
      setError("");
    } catch (err) {
      console.error("Erro ao comentar:", err);
    }
  };

  const handleReport = async () => {
    if (!reportModal || !user) return;
    const reason = sanitizeText(reportReason);
    const details = sanitizeText(reportDetails);

    try {
      await addDoc(collection(db, "reports"), {
        reporterId: user.uid,
        targetType: reportModal.type,
        targetId: reportModal.id,
        reason,
        details,
        status: "pending",
        createdAt: serverTimestamp(),
      });
      setReportModal(null);
      setReportReason("");
      setReportDetails("");
    } catch (err) {
      console.error("Erro ao denunciar:", err);
    }
  };

  const handleDeletePost = async (postId: string) => {
    if (!user) return;
    const post = posts.find((p) => p.id === postId);
    if (!post || post.authorId !== user.uid) return;

    try {
      await updateDoc(doc(db, "posts", postId), { isHidden: true });
      setActiveMenu(null);
    } catch (err) {
      console.error("Erro ao deletar:", err);
    }
  };

  const toggleComments = (postId: string) => {
    setExpandedComments((prev) => {
      const next = new Set(prev);
      if (next.has(postId)) {
        next.delete(postId);
      } else {
        next.add(postId);
      }
      return next;
    });
  };

  const formatTime = (timestamp: unknown) => {
    if (!timestamp) return "";
    const date =
      typeof timestamp === "object" && "toDate" in timestamp
        ? (timestamp as { toDate: () => Date }).toDate()
        : new Date(timestamp as string);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return "agora";
    if (minutes < 60) return `${minutes}min`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d`;
    return date.toLocaleDateString("pt-BR");
  };

  if (!user) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-white/50">Faça login para ver o feed.</p>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      {/* Create Post */}
      <div className="mb-6 rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-sm">
        <div className="flex gap-3">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 font-bold text-white">
            {profile?.displayName?.[0]?.toUpperCase() || "U"}
          </div>
          <div className="flex-1">
            <textarea
              value={newPost}
              onChange={(e) => {
                setNewPost(e.target.value);
                setError("");
              }}
              placeholder="O que está pensando?"
              className="w-full resize-none rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
              rows={3}
              maxLength={2000}
            />
            {showVideoInput && (
              <div className="mt-2">
                <input
                  type="url"
                  value={videoLink}
                  onChange={(e) => {
                    setVideoLink(e.target.value);
                    setError("");
                  }}
                  placeholder="Cole aqui o link do vídeo do YouTube"
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                />
              </div>
            )}
            <div className="mt-2 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="rounded-lg p-2 text-white/40 transition-colors hover:bg-white/10 hover:text-white/70">
                  <FiImage className="h-5 w-5" />
                </button>
                <button
                  type="button"
                  onClick={() => setShowVideoInput((v) => !v)}
                  title="Adicionar vídeo do YouTube"
                  className={`rounded-lg p-2 transition-colors hover:bg-white/10 hover:text-white/70 ${
                    showVideoInput ? "text-blue-400" : "text-white/40"
                  }`}
                >
                  <FiVideo className="h-5 w-5" />
                </button>
                <span className="text-xs text-white/30">
                  {newPost.length}/2000
                </span>
              </div>
              <button
                onClick={handleCreatePost}
                disabled={!sanitizeText(newPost)}
                className="flex items-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-blue-500 px-5 py-2 text-sm font-bold text-white shadow-md shadow-blue-500/20 transition-all hover:from-blue-500 hover:to-blue-400 disabled:opacity-30 disabled:shadow-none"
              >
                <FiSend className="h-4 w-4" />
                Publicar
              </button>
            </div>
          </div>
        </div>
        {error && (
          <div className="mt-3 flex items-center gap-2 rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">
            <FiAlertCircle className="h-4 w-4" />
            {error}
          </div>
        )}
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
        </div>
      )}

      {/* Posts */}
      {!loading && posts.length === 0 && (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-12 text-center">
          <p className="text-lg text-white/40">
            Nenhuma publicação ainda.
          </p>
          <p className="mt-2 text-sm text-white/30">
            Seja o primeiro a publicar!
          </p>
        </div>
      )}

      <div className="space-y-4">
        {posts.map((post) => (
          <article
            key={post.id}
            className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm transition-all hover:border-white/15"
          >
            {/* Post Header */}
            <div className="flex items-center justify-between px-4 pt-4">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 font-bold text-white">
                  {post.authorName?.[0]?.toUpperCase() || "U"}
                </div>
                <div>
                  <p className="font-semibold text-white">
                    {post.authorName}
                  </p>
                  <p className="text-xs text-white/40">
                    {formatTime(post.createdAt)}
                  </p>
                </div>
              </div>
              <div className="relative">
                <button
                  onClick={() =>
                    setActiveMenu(activeMenu === post.id ? null : post.id)
                  }
                  className="rounded-lg p-2 text-white/40 transition-colors hover:bg-white/10 hover:text-white/70"
                >
                  <FiMoreHorizontal className="h-5 w-5" />
                </button>
                {activeMenu === post.id && (
                  <div className="absolute right-0 top-10 z-10 w-48 rounded-xl border border-white/10 bg-gray-900 py-1 shadow-xl">
                    <button
                      onClick={() => {
                        setReportModal({ type: "post", id: post.id });
                        setActiveMenu(null);
                      }}
                      className="flex w-full items-center gap-2 px-4 py-2.5 text-sm text-white/70 transition-colors hover:bg-white/10"
                    >
                      <FiFlag className="h-4 w-4" />
                      Denunciar
                    </button>
                    {post.authorId === user?.uid && (
                      <button
                        onClick={() => handleDeletePost(post.id)}
                        className="flex w-full items-center gap-2 px-4 py-2.5 text-sm text-red-400 transition-colors hover:bg-white/10"
                      >
                        <FiTrash2 className="h-4 w-4" />
                        Excluir
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Post Content */}
            <div className="px-4 py-3">
              <p className="whitespace-pre-wrap text-white/90">
                {post.content}
              </p>
              {isValidYouTubeId(post.youtubeId) && (
                <div className="mt-3 aspect-video w-full overflow-hidden rounded-xl bg-black">
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${post.youtubeId}?rel=0`}
                    title="Vídeo do YouTube"
                    className="h-full w-full"
                    loading="lazy"
                    referrerPolicy="strict-origin-when-cross-origin"
                    allow="encrypted-media; picture-in-picture; fullscreen"
                    allowFullScreen
                  />
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 border-t border-white/5 px-4 py-2">
              <button
                onClick={() => handleLike(post.id)}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm transition-all ${
                  post.likes.includes(user.uid)
                    ? "font-medium text-red-400"
                    : "text-white/50 hover:bg-white/5 hover:text-white/70"
                }`}
              >
                <FiHeart
                  className={`h-4 w-4 ${
                    post.likes.includes(user.uid) ? "fill-current" : ""
                  }`}
                />
                {post.likes.length > 0 && post.likes.length}
              </button>
              <button
                onClick={() => toggleComments(post.id)}
                className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm text-white/50 transition-all hover:bg-white/5 hover:text-white/70"
              >
                <FiMessageCircle className="h-4 w-4" />
                {post.comments.length > 0 && post.comments.length}
              </button>
            </div>

            {/* Comments */}
            {expandedComments.has(post.id) && (
              <div className="border-t border-white/5 px-4 py-3">
                {/* Existing Comments */}
                {post.comments.length > 0 && (
                  <div className="mb-3 space-y-3">
                    {post.comments.map((comment) => (
                      <div
                        key={comment.id}
                        className="flex gap-2"
                      >
                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-xs font-bold text-white">
                          {comment.authorName?.[0]?.toUpperCase() || "U"}
                        </div>
                        <div className="rounded-xl bg-white/5 px-3 py-2">
                          <p className="text-xs font-semibold text-white/80">
                            {comment.authorName}
                          </p>
                          <p className="text-sm text-white/70">
                            {comment.content}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add Comment */}
                <div className="flex gap-2">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-blue-600 text-xs font-bold text-white">
                    {profile?.displayName?.[0]?.toUpperCase() || "U"}
                  </div>
                  <div className="flex flex-1 gap-2">
                    <input
                      type="text"
                      value={commentTexts[post.id] || ""}
                      onChange={(e) =>
                        setCommentTexts((prev) => ({
                          ...prev,
                          [post.id]: e.target.value,
                        }))
                      }
                      onKeyDown={(e) => {
                        if (e.key === "Enter") handleComment(post.id);
                      }}
                      placeholder="Escreva um comentário..."
                      className="flex-1 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white placeholder-white/30 outline-none transition-colors focus:border-blue-500/50"
                      maxLength={500}
                    />
                    <button
                      onClick={() => handleComment(post.id)}
                      disabled={!sanitizeText(commentTexts[post.id] || "")}
                      className="rounded-xl bg-blue-600 px-3 py-2 text-sm text-white transition-colors hover:bg-blue-500 disabled:opacity-30"
                    >
                      <FiSend className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </article>
        ))}
      </div>

      {/* Report Modal */}
      {reportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border border-white/10 bg-gray-900 p-6 shadow-2xl">
            <h3 className="mb-4 text-lg font-bold text-white">
              Denunciar conteúdo
            </h3>
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Motivo
                </label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 p-3 text-white outline-none focus:border-blue-500/50"
                >
                  <option value="">Selecione...</option>
                  <option value="spam">Spam</option>
                  <option value="harassment">Assédio/Bullying</option>
                  <option value="violence">Violência</option>
                  <option value="nudity">Conteúdo sexual</option>
                  <option value="hate">Discurso de ódio</option>
                  <option value="minor">Envolve menor de idade</option>
                  <option value="other">Outro</option>
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-white/70">
                  Detalhes (opcional)
                </label>
                <textarea
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  className="w-full resize-none rounded-xl border border-white/10 bg-white/5 p-3 text-white placeholder-white/30 outline-none focus:border-blue-500/50"
                  rows={3}
                  placeholder="Forneça mais detalhes..."
                  maxLength={1000}
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setReportModal(null);
                    setReportReason("");
                    setReportDetails("");
                  }}
                  className="flex-1 rounded-xl border border-white/10 py-3 text-sm font-medium text-white/70 transition-colors hover:bg-white/5"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleReport}
                  disabled={!reportReason}
                  className="flex-1 rounded-xl bg-red-600 py-3 text-sm font-bold text-white transition-all hover:bg-red-500 disabled:opacity-50"
                >
                  Denunciar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}