import { useState } from "react";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import Header from "./components/layout/Header";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import FeedPage from "./pages/FeedPage";
import ProfilePage from "./pages/ProfilePage";
import SettingsPage from "./pages/SettingsPage";
import RankingPage from "./pages/RankingPage";
import InstitutionsPage from "./pages/InstitutionsPage";
import ModerationPage from "./pages/ModerationPage";
import CompleteProfilePage from "./pages/CompleteProfilePage";
import ProfileSetupPage from "./pages/ProfileSetupPage";
import GuardianPendingPage from "./pages/GuardianPendingPage";
import GuardianApprovalsPage from "./pages/GuardianApprovalsPage";
import ScreenTimeGuard from "./components/ScreenTimeGuard";

function AppContent() {
  const { loading, user, profile, needsBirthDate, needsGuardian, guardianStatus } =
    useAuth();
  const [currentPage, setCurrentPage] = useState("home");

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950">
        <div className="flex flex-col items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-2xl shadow-blue-500/30">
            <span className="text-3xl font-black text-white">Z</span>
          </div>
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
          <p className="text-sm text-white/50">Carregando Zuca Social...</p>
        </div>
      </div>
    );
  }

  // Quem entrou (ex.: Google) mas ainda não informou a idade precisa completar o cadastro
  if (user && needsBirthDate) {
    return <CompleteProfilePage onDone={() => setCurrentPage("feed")} />;
  }

  // Contas de 13 a 16 anos só entram com a autorização do responsável (ECA Digital)
  if (user && profile && needsGuardian && guardianStatus !== "approved") {
    return <GuardianPendingPage />;
  }

  // Após informar a idade e concluir as proteções necessárias, cada pessoa
  // configura um nome de usuário único e sua biografia antes de acessar o feed.
  if (user && profile && profile.profileCompleted !== true) {
    return <ProfileSetupPage onDone={() => setCurrentPage("feed")} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage onNavigate={setCurrentPage} />;
      case "login":
        return <LoginPage onNavigate={setCurrentPage} />;
      case "register":
        return <RegisterPage onNavigate={setCurrentPage} />;
      case "feed":
        return <FeedPage />;
      case "profile":
        return <ProfilePage onNavigate={setCurrentPage} />;
      case "settings":
        return <SettingsPage onNavigate={setCurrentPage} />;
      case "ranking":
        return <RankingPage />;
      case "institutions":
        return <InstitutionsPage />;
      case "guardian":
        return <GuardianApprovalsPage />;
      case "moderation":
        return <ModerationPage onNavigate={setCurrentPage} />;
      default:
        return <HomePage onNavigate={setCurrentPage} />;
    }
  };

  return (
    <ScreenTimeGuard>
      <div className="min-h-screen bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950">
        <Header currentPage={currentPage} onNavigate={setCurrentPage} />
        <main>{renderPage()}</main>
      </div>
    </ScreenTimeGuard>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}