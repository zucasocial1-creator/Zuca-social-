import type { GamificationLevel, GamificationData } from "../types";

/** XP necessário para cada nível */
const LEVEL_THRESHOLDS: Record<GamificationLevel, number> = {
  Bronze: 0,
  Prata: 100,
  Ouro: 300,
  Esmeralda: 600,
  Ametista: 1000,
  Rubi: 1600,
  Diamante: 2500,
  Lendário: 4000,
};

const LEVEL_ORDER: GamificationLevel[] = [
  "Bronze",
  "Prata",
  "Ouro",
  "Esmeralda",
  "Ametista",
  "Rubi",
  "Diamante",
  "Lendário",
];

export function getLevelForXP(totalXP: number): GamificationLevel {
  let level: GamificationLevel = "Bronze";
  for (const lvl of LEVEL_ORDER) {
    if (totalXP >= LEVEL_THRESHOLDS[lvl]) {
      level = lvl;
    }
  }
  return level;
}

export function getXPForNextLevel(currentLevel: GamificationLevel): number {
  const idx = LEVEL_ORDER.indexOf(currentLevel);
  if (idx < LEVEL_ORDER.length - 1) {
    return LEVEL_THRESHOLDS[LEVEL_ORDER[idx + 1]];
  }
  return LEVEL_THRESHOLDS["Lendário"];
}

export function getLevelIcon(level: GamificationLevel): string {
  const icons: Record<GamificationLevel, string> = {
    Bronze: "🥉",
    Prata: "🥈",
    Ouro: "🥇",
    Esmeralda: "💎",
    Ametista: "🔮",
    Rubi: "❤️",
    Diamante: "💠",
    Lendário: "👑",
  };
  return icons[level];
}

export function getLevelColor(level: GamificationLevel): string {
  const colors: Record<GamificationLevel, string> = {
    Bronze: "from-amber-700 to-amber-500",
    Prata: "from-gray-400 to-gray-300",
    Ouro: "from-yellow-500 to-yellow-300",
    Esmeralda: "from-emerald-600 to-emerald-400",
    Ametista: "from-purple-600 to-purple-400",
    Rubi: "from-red-600 to-red-400",
    Diamante: "from-cyan-500 to-blue-400",
    Lendário: "from-amber-500 via-yellow-400 to-amber-600",
  };
  return colors[level];
}

/** Ações que concedem XP (valores server-side devem prevalecer) */
export const XP_REWARDS = {
  CREATE_POST: 10,
  LIKE_POST: 2,
  RECEIVE_LIKE: 5,
  COMMENT: 5,
  RECEIVE_COMMENT: 3,
  DAILY_LOGIN: 5,
  STREAK_BONUS: 10, // por dia de sequência
  COMPLETE_PROFILE: 20,
  FIRST_POST: 25,
};

/**
 * Calcula o bônus de sequência diária.
 * NOTA: O cálculo real deve ser feito no servidor.
 */
export function calculateStreakBonus(streak: number): number {
  return Math.min(streak * XP_REWARDS.STREAK_BONUS, 100);
}

export function updateGamification(
  current: GamificationData,
  xpGained: number
): GamificationData {
  const newXP = current.xp + xpGained;
  const totalXP = current.points + newXP;
  const newLevel = getLevelForXP(totalXP);
  const nextLevelXP = getXPForNextLevel(newLevel);

  return {
    ...current,
    xp: newXP,
    points: totalXP,
    level: newLevel,
    xpToNextLevel: nextLevelXP - totalXP,
  };
}