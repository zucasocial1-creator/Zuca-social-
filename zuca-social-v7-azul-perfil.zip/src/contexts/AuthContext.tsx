import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  signOut,
  sendPasswordResetEmail,
  updateProfile,
  deleteUser,
  type User,
} from "firebase/auth";
import { doc, getDoc, setDoc, updateDoc } from "firebase/firestore";
import { auth, googleProvider, db } from "../config/firebase";
import type {
  UserProfile,
  GamificationData,
  GuardianRequest,
  GuardianStatus,
} from "../types";
import { calculateAge, isValidEmail } from "../utils/sanitize";
import { needsGuardianFor } from "../utils/guardian";

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  /** true quando a pessoa entrou (ex.: Google) mas ainda não informou a data de nascimento */
  needsBirthDate: boolean;
  /** true quando a conta é de 13 a 16 anos e precisa de responsável */
  needsGuardian: boolean;
  /** situação da autorização do responsável (null se não se aplica) */
  guardianStatus: GuardianStatus | null;
  /** limite diário (minutos) definido pelo responsável; null = padrão (5 h) */
  guardianLimitMinutes: number | null;
  login: (email: string, password: string) => Promise<void>;
  register: (
    email: string,
    password: string,
    displayName: string,
    birthDate: string,
    guardianEmail?: string
  ) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  /** Salva a data de nascimento e cria/atualiza o perfil com a proteção de menores correta */
  completeProfile: (birthDate: string, guardianEmail?: string) => Promise<void>;
  /** Envia (ou troca) o e-mail do responsável e abre o pedido de autorização */
  submitGuardianEmail: (guardianEmail: string) => Promise<void>;
  refreshGuardianStatus: () => Promise<void>;
  /** Atualiza autorização e limite em segundo plano (ignora falhas de rede) */
  syncGuardian: () => Promise<void>;
  /** Sai do cadastro. Com deleteAccount=true, também apaga a conta de login. */
  leaveSignup: (deleteAccount: boolean) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

const DEFAULT_GAMIFICATION: GamificationData = {
  points: 0,
  level: "Bronze",
  xp: 0,
  xpToNextLevel: 100,
  streak: 0,
  lastActiveDate: new Date().toISOString().split("T")[0],
  badges: [],
  completedMissions: [],
};

const MIN_AGE = 13;

/** Valida o e-mail do responsável. Lança erros com códigos tratados nas telas. */
function checkGuardianEmail(raw: string | undefined, ownEmail: string): string {
  const email = (raw || "").trim().toLowerCase();
  if (!email) throw new Error("guardian-email-required");
  if (!isValidEmail(email)) throw new Error("guardian-email-invalid");
  if (email === ownEmail.trim().toLowerCase())
    throw new Error("guardian-email-same");
  return email;
}

function buildProfile(
  uid: string,
  email: string,
  displayName: string,
  photoURL: string,
  birthDate: string,
  guardianEmail: string
): UserProfile {
  const age = calculateAge(birthDate);
  const isMinor = age < 18;
  const needs = needsGuardianFor(birthDate);
  return {
    uid,
    email,
    displayName,
    photoURL,
    bio: "",
    birthDate,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    isMinor,
    role: "user",
    isBlocked: false,
    blockedUsers: [],
    privacyLevel: isMinor ? "friends" : "public",
    gamification: DEFAULT_GAMIFICATION,
    zucaCreator: false,
    requiresGuardian: needs,
    // Firestore não aceita "undefined": só inclui o campo quando existe
    ...(needs ? { guardianEmail } : {}),
  };
}

async function createGuardianRequest(
  minorUid: string,
  minorName: string,
  guardianEmail: string
) {
  const now = new Date().toISOString();
  const req: GuardianRequest = {
    minorUid,
    minorName,
    guardianEmail,
    status: "pending",
    createdAt: now,
    updatedAt: now,
  };
  await setDoc(doc(db, "guardianRequests", minorUid), req);
}

interface GuardianInfo {
  status: GuardianStatus;
  limitMinutes: number | null;
}

/** Lê o pedido do responsável. Retorna null se não conseguiu ler (erro de rede/regras). */
async function loadGuardian(uid: string): Promise<GuardianInfo | null> {
  try {
    const snap = await getDoc(doc(db, "guardianRequests", uid));
    if (!snap.exists()) return { status: "missing", limitMinutes: null };
    const data = snap.data() as GuardianRequest;
    return {
      status: data.status,
      limitMinutes:
        typeof data.dailyLimitMinutes === "number"
          ? data.dailyLimitMinutes
          : null,
    };
  } catch (err) {
    console.error("Erro ao verificar autorização do responsável:", err);
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [needsBirthDate, setNeedsBirthDate] = useState(false);
  const [guardianStatus, setGuardianStatus] = useState<GuardianStatus | null>(
    null
  );
  const [guardianLimitMinutes, setGuardianLimitMinutes] = useState<
    number | null
  >(null);

  // Aplica o resultado da leitura. Se não conseguiu ler, por segurança trata como "sem autorização".
  const applyGuardian = (info: GuardianInfo | null) => {
    const i: GuardianInfo = info ?? { status: "missing", limitMinutes: null };
    setGuardianStatus(i.status);
    setGuardianLimitMinutes(i.limitMinutes);
  };

  // Evita corrida: durante o cadastro por e-mail o perfil é criado pela função register()
  const registeringRef = useRef(false);

  const needsGuardian = !!profile && needsGuardianFor(profile.birthDate);

  const refreshProfile = async () => {
    if (!user) return;
    try {
      const snap = await getDoc(doc(db, "users", user.uid));
      if (snap.exists()) {
        setProfile(snap.data() as UserProfile);
      }
    } catch (err) {
      console.error("Erro ao carregar perfil:", err);
    }
  };

  const refreshGuardianStatus = async () => {
    if (!user) return;
    applyGuardian(await loadGuardian(user.uid));
  };

  const syncGuardian = async () => {
    if (!user) return;
    const info = await loadGuardian(user.uid);
    if (info) applyGuardian(info); // falha de rede não derruba quem já está usando
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        if (registeringRef.current) {
          setLoading(false);
          return;
        }
        setLoading(true);
        try {
          const snap = await getDoc(doc(db, "users", firebaseUser.uid));
          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            setProfile(data);
            // Contas antigas criadas pelo Google sem data de nascimento também precisam informar
            setNeedsBirthDate(!data.birthDate);
            if (needsGuardianFor(data.birthDate)) {
              applyGuardian(await loadGuardian(firebaseUser.uid));
            } else {
              setGuardianStatus(null);
        setGuardianLimitMinutes(null);
            }
          } else {
            // Primeiro acesso (ex.: Google): NÃO cria o perfil ainda.
            // Primeiro precisamos saber a idade para proteger menores.
            setProfile(null);
            setNeedsBirthDate(true);
            setGuardianStatus(null);
        setGuardianLimitMinutes(null);
          }
        } catch (err) {
          console.error("Erro ao buscar perfil:", err);
        }
      } else {
        setProfile(null);
        setNeedsBirthDate(false);
        setGuardianStatus(null);
        setGuardianLimitMinutes(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string) => {
    await signInWithEmailAndPassword(auth, email, password);
  };

  const register = async (
    email: string,
    password: string,
    displayName: string,
    birthDate: string,
    guardianEmail?: string
  ) => {
    // Valida o responsável ANTES de criar a conta, para não deixar conta pela metade
    const needs = needsGuardianFor(birthDate);
    const gEmail = needs ? checkGuardianEmail(guardianEmail, email) : "";

    registeringRef.current = true;
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(cred.user, { displayName });

      const newProfile = buildProfile(
        cred.user.uid,
        email,
        displayName,
        "",
        birthDate,
        gEmail
      );

      await setDoc(doc(db, "users", cred.user.uid), newProfile);
      if (needs) {
        await createGuardianRequest(cred.user.uid, displayName, gEmail);
      }
      setProfile(newProfile);
      setNeedsBirthDate(false);
      setGuardianStatus(needs ? "pending" : null);
    } finally {
      registeringRef.current = false;
    }
  };

  const loginWithGoogle = async () => {
    // O perfil é tratado em onAuthStateChanged: se não existir,
    // a pessoa será levada à tela de data de nascimento.
    await signInWithPopup(auth, googleProvider);
  };

  const completeProfile = async (birthDate: string, guardianEmail?: string) => {
    if (!user) throw new Error("not-authenticated");

    const birth = new Date(birthDate);
    const today = new Date();
    if (!birthDate || isNaN(birth.getTime()) || birth >= today) {
      throw new Error("invalid-birthdate");
    }
    const age = calculateAge(birthDate);
    if (age > 120) throw new Error("invalid-birthdate");
    if (age < MIN_AGE) throw new Error("under-13");

    const needs = needsGuardianFor(birthDate);
    const gEmail = needs ? checkGuardianEmail(guardianEmail, user.email || "") : "";

    const ref = doc(db, "users", user.uid);
    const snap = await getDoc(ref);
    let finalProfile: UserProfile;

    if (snap.exists()) {
      // Conta antiga sem data de nascimento: só completa os campos de idade
      const existing = snap.data() as UserProfile;
      const isMinor = age < 18;
      const updates = {
        birthDate,
        isMinor,
        privacyLevel:
          isMinor && existing.privacyLevel === "public"
            ? ("friends" as const)
            : existing.privacyLevel,
        requiresGuardian: needs,
        updatedAt: new Date().toISOString(),
        ...(needs ? { guardianEmail: gEmail } : {}),
      };
      await setDoc(ref, updates, { merge: true });
      finalProfile = { ...existing, ...updates };
    } else {
      finalProfile = buildProfile(
        user.uid,
        user.email || "",
        user.displayName || "Usuário",
        user.photoURL || "",
        birthDate,
        gEmail
      );
      await setDoc(ref, finalProfile);
    }

    if (needs) {
      await createGuardianRequest(user.uid, finalProfile.displayName, gEmail);
    }
    setProfile(finalProfile);
    setGuardianStatus(needs ? "pending" : null);
    setNeedsBirthDate(false);
  };

  const submitGuardianEmail = async (guardianEmail: string) => {
    if (!user || !profile) throw new Error("not-authenticated");
    const gEmail = checkGuardianEmail(guardianEmail, user.email || "");
    const now = new Date().toISOString();

    const reqRef = doc(db, "guardianRequests", user.uid);
    const snap = await getDoc(reqRef);
    if (snap.exists()) {
      const current = snap.data() as GuardianRequest;
      if (current.status !== "pending") throw new Error("request-closed");
      await updateDoc(reqRef, { guardianEmail: gEmail, updatedAt: now });
    } else {
      await createGuardianRequest(user.uid, profile.displayName, gEmail);
    }

    // Marca a conta como "precisa de responsável" (também cobre contas antigas)
    await setDoc(
      doc(db, "users", user.uid),
      { requiresGuardian: true, guardianEmail: gEmail, updatedAt: now },
      { merge: true }
    );
    setProfile({
      ...profile,
      requiresGuardian: true,
      guardianEmail: gEmail,
      updatedAt: now,
    });
    setGuardianStatus("pending");
  };

  const leaveSignup = async (deleteAccount: boolean) => {
    if (deleteAccount && auth.currentUser) {
      try {
        await deleteUser(auth.currentUser);
      } catch (err) {
        console.error("Não foi possível apagar a conta, saindo:", err);
        await signOut(auth);
      }
    } else {
      await signOut(auth);
    }
    setProfile(null);
    setNeedsBirthDate(false);
    setGuardianStatus(null);
        setGuardianLimitMinutes(null);
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
    setGuardianStatus(null);
        setGuardianLimitMinutes(null);
  };

  const resetPassword = async (email: string) => {
    await sendPasswordResetEmail(auth, email);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        needsBirthDate,
        needsGuardian,
        guardianStatus,
        guardianLimitMinutes,
        login,
        register,
        loginWithGoogle,
        completeProfile,
        submitGuardianEmail,
        refreshGuardianStatus,
        syncGuardian,
        leaveSignup,
        logout,
        resetPassword,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth deve ser usado dentro de um AuthProvider");
  }
  return context;
}
