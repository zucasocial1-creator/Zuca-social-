import { useCallback, useEffect, useState } from "react";
import {
  collection,
  doc,
  getDocs,
  query,
  updateDoc,
  where,
} from "firebase/firestore";
import { sendEmailVerification } from "firebase/auth";
import { FiShield, FiCheck, FiX, FiAlertCircle } from "react-icons/fi";
import { auth, db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import type { GuardianRequest } from "../types";
import { formatDuration } from "../utils/screenTime";

type Row = GuardianRequest & { id: string };

// Opções de tempo por dia que o responsável pode escolher (máximo 5 horas)
const LIMIT_OPTIONS = [60, 120, 180, 240, 300];

/**
 * Tela do RESPONSÁVEL (maior de 18 anos): aprova, recusa ou revoga
 * o acesso de menores que indicaram o e-mail dele.
 */
export default function GuardianApprovalsPage() {
  const { user, profile } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [verified, setVerified] = useState(!!auth.currentUser?.emailVerified);

  const isAdult = !!profile && !!profile.birthDate && !profile.isMinor;
  const email = (user?.email || "").toLowerCase();

  const load = useCallback(async () => {
    if (!email) return;
    setLoading(true);
    setError("");
    try {
      const q = query(
        collection(db, "guardianRequests"),
        where("guardianEmail", "==", email)
      );
      const snap = await getDocs(q);
      const list = snap.docs.map((d) => ({
        id: d.id,
        ...(d.data() as GuardianRequest),
      }));
      list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
      setRows(list);
    } catch (err) {
      console.error("Erro ao carregar pedidos:", err);
      setError(
        "Não foi possível carregar os pedidos. Confirme seu e-mail e tente de novo."
      );
    } finally {
      setLoading(false);
    }
  }, [email]);

  useEffect(() => {
    if (isAdult && verified) load();
    else setLoading(false);
  }, [isAdult, verified, load]);

  const sendVerification = async () => {
    setError("");
    setInfo("");
    try {
      if (!auth.currentUser) return;
      await sendEmailVerification(auth.currentUser);
      setInfo("Enviamos um e-mail de confirmação. Abra o link e volte aqui.");
    } catch (err) {
      console.error(err);
      setError("Não foi possível enviar o e-mail agora. Tente mais tarde.");
    }
  };

  const checkVerified = async () => {
    setError("");
    setInfo("");
    try {
      if (!auth.currentUser) return;
      await auth.currentUser.reload();
      // Atualiza o "crachá" de login para as regras enxergarem o e-mail confirmado
      await auth.currentUser.getIdToken(true);
      const ok = !!auth.currentUser.emailVerified;
      setVerified(ok);
      if (!ok) setInfo("Ainda não aparece como confirmado. Abra o link do e-mail e tente de novo.");
    } catch (err) {
      console.error(err);
      setError("Não foi possível verificar agora.");
    }
  };

  const decide = async (id: string, status: "approved" | "denied") => {
    if (!user) return;
    setError("");
    try {
      await updateDoc(doc(db, "guardianRequests", id), {
        status,
        decidedAt: new Date().toISOString(),
        decidedBy: user.uid,
      });
      await load();
    } catch (err) {
      console.error("Erro ao registrar decisão:", err);
      setError("Não foi possível registrar sua decisão. Tente novamente.");
    }
  };

  const setLimit = async (id: string, minutes: number) => {
    setError("");
    setInfo("");
    try {
      await updateDoc(doc(db, "guardianRequests", id), {
        dailyLimitMinutes: minutes,
        updatedAt: new Date().toISOString(),
      });
      await load();
      setInfo("Limite de tempo atualizado.");
    } catch (err) {
      console.error("Erro ao salvar limite:", err);
      setError("Não foi possível salvar o limite. Tente novamente.");
    }
  };

  const badge = (s: Row["status"]) =>
    s === "approved"
      ? "bg-blue-500/20 text-blue-300"
      : s === "denied"
      ? "bg-red-500/20 text-red-300"
      : "bg-yellow-500/20 text-yellow-200";
  const label = (s: Row["status"]) =>
    s === "approved" ? "Autorizado" : s === "denied" ? "Recusado" : "Aguardando";

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <div className="mb-6 flex items-center gap-3">
        <FiShield className="h-7 w-7 text-blue-400" />
        <div>
          <h1 className="text-2xl font-bold text-white">Autorizações</h1>
          <p className="text-sm text-white/50">
            Aqui o responsável autoriza menores de até 16 anos a usar o Zuca
            Social.
          </p>
        </div>
      </div>

      {error && (
        <div className="mb-4 flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
          <FiAlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {info && (
        <div className="mb-4 rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-white/70">
          {info}
        </div>
      )}

      {!isAdult ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6 text-sm text-white/60">
          Só contas de maiores de 18 anos, com data de nascimento informada,
          podem autorizar outras contas.
        </div>
      ) : !verified ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <p className="mb-4 text-sm text-white/70">
            Para proteger os menores, precisamos confirmar que o e-mail{" "}
            <strong>{user?.email}</strong> é realmente seu antes de você poder
            autorizar alguém.
          </p>
          <button
            onClick={sendVerification}
            className="mb-3 w-full rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 py-3 font-semibold text-white"
          >
            Enviar e-mail de confirmação
          </button>
          <button
            onClick={checkVerified}
            className="w-full rounded-xl border border-white/10 py-3 text-sm text-white/70"
          >
            Já confirmei
          </button>
        </div>
      ) : loading ? (
        <p className="text-sm text-white/50">Carregando...</p>
      ) : rows.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-6 text-sm text-white/60">
          Nenhum pedido para <strong>{user?.email}</strong> por enquanto. Quando
          um menor informar este e-mail como responsável, o pedido aparece aqui.
        </div>
      ) : (
        <ul className="space-y-3">
          {rows.map((r) => (
            <li
              key={r.id}
              className="rounded-2xl border border-white/10 bg-white/5 p-4"
            >
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <p className="font-semibold text-white">{r.minorName}</p>
                  <p className="text-xs text-white/40">
                    Pedido em {new Date(r.createdAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <span
                  className={`rounded-full px-3 py-1 text-xs font-medium ${badge(
                    r.status
                  )}`}
                >
                  {label(r.status)}
                </span>
              </div>
              {r.status === "approved" && (
                <div className="mb-3 flex items-center justify-between gap-3 text-sm text-white/70">
                  <span>Tempo por dia no Zuca</span>
                  <select
                    value={r.dailyLimitMinutes ?? 300}
                    onChange={(e) => setLimit(r.id, Number(e.target.value))}
                    className="rounded-lg border border-white/10 bg-gray-900 px-2 py-1 text-white"
                  >
                    {LIMIT_OPTIONS.map((m) => (
                      <option key={m} value={m}>
                        {formatDuration(m * 60)}
                      </option>
                    ))}
                  </select>
                </div>
              )}
              <div className="flex gap-2">
                {r.status !== "approved" && (
                  <button
                    onClick={() => decide(r.id, "approved")}
                    className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-blue-600 py-2 text-sm font-semibold text-white"
                  >
                    <FiCheck className="h-4 w-4" /> Autorizar
                  </button>
                )}
                {r.status !== "denied" && (
                  <button
                    onClick={() => decide(r.id, "denied")}
                    className="flex flex-1 items-center justify-center gap-1 rounded-xl border border-red-500/40 py-2 text-sm text-red-300"
                  >
                    <FiX className="h-4 w-4" />{" "}
                    {r.status === "approved" ? "Revogar" : "Recusar"}
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
