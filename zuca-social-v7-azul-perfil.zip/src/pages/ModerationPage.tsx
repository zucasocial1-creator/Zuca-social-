import { useState, useEffect } from "react";
import {
  collection,
  query,
  where,
  orderBy,
  getDocs,
  updateDoc,
  doc,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "../config/firebase";
import { useAuth } from "../contexts/AuthContext";
import type { Report } from "../types";
import {
  FiShield,
  FiAlertTriangle,
  FiCheckCircle,
  FiXCircle,
  FiClock,
  FiUser,
  FiFileText,
  FiMessageSquare,
} from "react-icons/fi";

interface ModerationPageProps {
  onNavigate: (page: string) => void;
}

export default function ModerationPage({ onNavigate }: ModerationPageProps) {
  const { profile } = useAuth();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState<
    "pending" | "reviewed" | "resolved" | "dismissed" | "all"
  >("pending");

  const isAuthorized =
    profile?.role === "admin" || profile?.role === "moderator";

  useEffect(() => {
    if (!isAuthorized) return;

    const loadReports = async () => {
      try {
        const reportsRef = collection(db, "reports");
        let q;
        if (activeFilter === "all") {
          q = query(reportsRef, orderBy("createdAt", "desc"));
        } else {
          q = query(
            reportsRef,
            where("status", "==", activeFilter),
            orderBy("createdAt", "desc")
          );
        }
        const snapshot = await getDocs(q);

        const reportList: Report[] = [];
        snapshot.forEach((doc) => {
          reportList.push({ id: doc.id, ...doc.data() } as Report);
        });
        setReports(reportList);
      } catch (err) {
        console.error("Erro ao carregar denúncias:", err);
      }
      setLoading(false);
    };

    loadReports();
  }, [activeFilter, isAuthorized]);

  const handleUpdateStatus = async (
    reportId: string,
    status: "reviewed" | "resolved" | "dismissed"
  ) => {
    if (!profile) return;
    try {
      await updateDoc(doc(db, "reports", reportId), {
        status,
        reviewedAt: serverTimestamp(),
        reviewedBy: profile.uid,
      });

      // If resolved and target is post, hide it
      if (status === "resolved") {
        const report = reports.find((r) => r.id === reportId);
        if (report?.targetType === "post") {
          await updateDoc(doc(db, "posts", report.targetId), {
            isHidden: true,
          });
        }
      }

      // Refresh
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId ? { ...r, status, reviewedBy: profile.uid } : r
        )
      );
    } catch (err) {
      console.error("Erro ao atualizar denúncia:", err);
    }
  };

  const handleBlockUser = async (userId: string) => {
    try {
      await updateDoc(doc(db, "users", userId), {
        isBlocked: true,
        updatedAt: new Date().toISOString(),
      });
    } catch (err) {
      console.error("Erro ao bloquear usuário:", err);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "text-amber-400 bg-amber-500/10 border-amber-500/30";
      case "reviewed":
        return "text-blue-400 bg-blue-500/10 border-blue-500/30";
      case "resolved":
        return "text-blue-400 bg-blue-500/10 border-blue-500/30";
      case "dismissed":
        return "text-white/40 bg-white/5 border-white/10";
      default:
        return "text-white/40 bg-white/5 border-white/10";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <FiClock className="h-4 w-4" />;
      case "reviewed":
        return <FiAlertTriangle className="h-4 w-4" />;
      case "resolved":
        return <FiCheckCircle className="h-4 w-4" />;
      case "dismissed":
        return <FiXCircle className="h-4 w-4" />;
      default:
        return <FiClock className="h-4 w-4" />;
    }
  };

  const getTargetIcon = (type: string) => {
    switch (type) {
      case "post":
        return <FiFileText className="h-4 w-4" />;
      case "comment":
        return <FiMessageSquare className="h-4 w-4" />;
      case "user":
        return <FiUser className="h-4 w-4" />;
      default:
        return <FiFileText className="h-4 w-4" />;
    }
  };

  const getReasonLabel = (reason: string) => {
    const labels: Record<string, string> = {
      spam: "Spam",
      harassment: "Assédio/Bullying",
      violence: "Violência",
      nudity: "Conteúdo sexual",
      hate: "Discurso de ódio",
      minor: "Envolve menor de idade",
      other: "Outro",
    };
    return labels[reason] || reason;
  };

  const formatTime = (timestamp: unknown) => {
    if (!timestamp) return "";
    const date =
      typeof timestamp === "object" && "toDate" in timestamp
        ? (timestamp as { toDate: () => Date }).toDate()
        : new Date(timestamp as string);
    return date.toLocaleString("pt-BR");
  };

  if (!isAuthorized) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
        <FiShield className="h-16 w-16 text-red-400/50" />
        <p className="text-lg text-white/50">Acesso restrito a moderadores.</p>
        <button
          onClick={() => onNavigate("feed")}
          className="rounded-xl border border-white/10 px-6 py-2 text-sm text-white/60 hover:bg-white/5"
        >
          ← Voltar ao Feed
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      <div className="mb-6">
        <h1 className="flex items-center gap-3 text-2xl font-bold text-white">
          <FiShield className="h-7 w-7 text-blue-400" />
          Painel de Moderação
        </h1>
        <p className="mt-1 text-sm text-white/50">
          Gerencie denúncias e mantenha a comunidade segura
        </p>
      </div>

      {/* Stats */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {[
          {
            label: "Pendentes",
            count: reports.filter((r) => r.status === "pending").length,
            color: "text-amber-400",
          },
          {
            label: "Em análise",
            count: reports.filter((r) => r.status === "reviewed").length,
            color: "text-blue-400",
          },
          {
            label: "Resolvidas",
            count: reports.filter((r) => r.status === "resolved").length,
            color: "text-blue-400",
          },
          {
            label: "Dispensadas",
            count: reports.filter((r) => r.status === "dismissed").length,
            color: "text-white/40",
          },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl border border-white/10 bg-white/5 p-4 text-center"
          >
            <p className={`text-2xl font-bold ${stat.color}`}>{stat.count}</p>
            <p className="mt-1 text-xs text-white/50">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="mb-6 flex gap-1 overflow-x-auto rounded-xl border border-white/10 bg-white/5 p-1">
        {[
          { id: "pending", label: "Pendentes" },
          { id: "reviewed", label: "Em Análise" },
          { id: "resolved", label: "Resolvidas" },
          { id: "dismissed", label: "Dispensadas" },
          { id: "all", label: "Todas" },
        ].map((filter) => (
          <button
            key={filter.id}
            onClick={() =>
              setActiveFilter(
                filter.id as
                  | "pending"
                  | "reviewed"
                  | "resolved"
                  | "dismissed"
                  | "all"
              )
            }
            className={`whitespace-nowrap rounded-lg px-4 py-2 text-sm font-medium transition-all ${
              activeFilter === filter.id
                ? "bg-white/15 text-white"
                : "text-white/50 hover:bg-white/5"
            }`}
          >
            {filter.label}
          </button>
        ))}
      </div>

      {/* Reports */}
      {loading ? (
        <div className="flex justify-center py-12">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-blue-500 border-t-transparent" />
        </div>
      ) : reports.length === 0 ? (
        <div className="rounded-2xl border border-white/10 bg-white/5 p-12 text-center">
          <FiCheckCircle className="mx-auto mb-3 h-12 w-12 text-blue-400/30" />
          <p className="text-lg text-white/40">Nenhuma denúncia encontrada.</p>
          <p className="mt-2 text-sm text-white/30">
            A comunidade está tranquila! 🎉
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {reports.map((report) => (
            <div
              key={report.id}
              className="rounded-2xl border border-white/10 bg-white/5 p-5"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div
                    className={`flex items-center gap-1.5 rounded-lg border px-2.5 py-1 text-xs font-medium ${getStatusColor(
                      report.status
                    )}`}
                  >
                    {getStatusIcon(report.status)}
                    {report.status === "pending"
                      ? "Pendente"
                      : report.status === "reviewed"
                      ? "Em análise"
                      : report.status === "resolved"
                      ? "Resolvida"
                      : "Dispensada"}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-white/40">
                    {getTargetIcon(report.targetType)}
                    {report.targetType === "post"
                      ? "Publicação"
                      : report.targetType === "comment"
                      ? "Comentário"
                      : "Usuário"}
                  </div>
                </div>
                <span className="text-xs text-white/30">
                  {formatTime(report.createdAt)}
                </span>
              </div>

              <div className="mt-3">
                <p className="text-sm text-white/70">
                  <span className="font-medium text-white">Motivo:</span>{" "}
                  {getReasonLabel(report.reason)}
                </p>
                {report.details && (
                  <p className="mt-1 text-sm text-white/50">
                    {report.details}
                  </p>
                )}
                <p className="mt-1 text-xs text-white/30">
                  Denúncia #{report.id.slice(0, 8)} • Denunciante:{" "}
                  {report.reporterId.slice(0, 8)}...
                </p>
              </div>

              {/* Actions */}
              {report.status === "pending" && (
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => handleUpdateStatus(report.id, "reviewed")}
                    className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium text-white hover:bg-blue-500"
                  >
                    <FiAlertTriangle className="h-3.5 w-3.5" />
                    Analisar
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(report.id, "resolved")}
                    className="flex items-center gap-1.5 rounded-lg bg-red-600 px-3 py-2 text-xs font-medium text-white hover:bg-red-500"
                  >
                    <FiCheckCircle className="h-3.5 w-3.5" />
                    Resolver (ocultar conteúdo)
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(report.id, "dismissed")}
                    className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-white/60 hover:bg-white/5"
                  >
                    <FiXCircle className="h-3.5 w-3.5" />
                    Dispensar
                  </button>
                  {report.targetType === "user" && (
                    <button
                      onClick={() => handleBlockUser(report.targetId)}
                      className="flex items-center gap-1.5 rounded-lg bg-blue-800 px-3 py-2 text-xs font-medium text-white hover:bg-red-700"
                    >
                      <FiUser className="h-3.5 w-3.5" />
                      Bloquear Usuário
                    </button>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Info */}
      <div className="mt-6 rounded-xl border border-white/10 bg-white/5 p-4">
        <h3 className="mb-2 text-sm font-semibold text-white/70">
          Diretrizes de Moderação
        </h3>
        <ul className="space-y-1 text-xs text-white/40">
          <li>• Denúncias envolvendo menores de idade têm prioridade máxima.</li>
          <li>• Conteúdo resolvido é ocultado automaticamente do feed.</li>
          <li>• Usuários bloqueados perdem acesso à plataforma.</li>
          <li>• Todas as ações são registradas para auditoria.</li>
          <li>• Em caso de dúvida, consulte a equipe jurídica.</li>
        </ul>
      </div>
    </div>
  );
}