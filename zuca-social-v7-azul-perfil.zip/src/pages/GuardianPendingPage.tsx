import { useState } from "react";
import { FiMail, FiAlertCircle, FiRefreshCw } from "react-icons/fi";
import { useAuth } from "../contexts/AuthContext";
import { guardianErrorMessage } from "../utils/guardian";

/**
 * Tela mostrada a quem tem 13 a 16 anos enquanto o responsável
 * ainda não autorizou a conta (ECA Digital: conta vinculada a responsável legal).
 */
export default function GuardianPendingPage() {
  const {
    profile,
    guardianStatus,
    submitGuardianEmail,
    refreshGuardianStatus,
    logout,
  } = useAuth();
  const [guardianEmail, setGuardianEmail] = useState(
    profile?.guardianEmail || ""
  );
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setInfo("");
    setLoading(true);
    try {
      await submitGuardianEmail(guardianEmail);
      setInfo("Pedido salvo! Avise seu responsável para autorizar.");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "";
      setError(
        guardianErrorMessage(msg) ||
          "Não foi possível salvar o pedido. Tente novamente."
      );
      console.error("Erro no pedido ao responsável:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setError("");
    setInfo("");
    setLoading(true);
    await refreshGuardianStatus();
    setLoading(false);
    setInfo("Situação atualizada.");
  };

  const shell = (children: React.ReactNode) => (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-blue-950 via-slate-950 to-blue-950 px-4 py-12">
      <div className="w-full max-w-md rounded-2xl border border-white/10 bg-white/5 p-8 shadow-2xl backdrop-blur-sm">
        {children}
      </div>
    </div>
  );

  if (guardianStatus === "denied") {
    return shell(
      <div className="text-center">
        <h1 className="mb-3 text-xl font-bold text-white">
          Autorização não concedida
        </h1>
        <p className="mb-6 text-sm text-white/60">
          Seu responsável não autorizou esta conta, então ela não pode ser
          usada por enquanto. Converse com ele ou ela; se mudar de ideia, a
          autorização pode ser dada depois.
        </p>
        <button
          onClick={handleRefresh}
          disabled={loading}
          className="mb-3 w-full rounded-xl border border-white/10 py-3 text-sm text-white/70"
        >
          Verificar de novo
        </button>
        <button
          onClick={logout}
          className="w-full py-2 text-sm text-white/40 hover:text-white/70"
        >
          Sair
        </button>
      </div>
    );
  }

  const hasRequest = guardianStatus === "pending";

  return shell(
    <>
      <div className="mb-5 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 shadow-lg">
          <span className="text-3xl font-black text-white">Z</span>
        </div>
        <h1 className="text-xl font-bold text-white">
          Falta a autorização do seu responsável
        </h1>
        <p className="mt-2 text-sm text-white/50">
          Para quem tem até 16 anos, a conta precisa estar vinculada a um
          responsável (pai, mãe ou responsável legal maior de 18 anos).
        </p>
      </div>

      {hasRequest && (
        <div className="mb-4 rounded-xl border border-blue-500/20 bg-blue-500/10 p-3 text-sm text-blue-200">
          Pedido enviado para <strong>{profile?.guardianEmail}</strong>.
          Aguardando a aprovação.
        </div>
      )}

      <ol className="mb-5 list-decimal space-y-1 pl-5 text-sm text-white/60">
        <li>
          Seu responsável cria uma conta no Zuca Social usando exatamente o
          e-mail abaixo.
        </li>
        <li>Ele confirma o e-mail e abre o menu “Autorizações”.</li>
        <li>Ele toca em “Autorizar”. Depois, volte aqui e toque em Atualizar.</li>
      </ol>

      {error && (
        <div className="mb-4 flex items-start gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-300">
          <FiAlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}
      {info && (
        <div className="mb-4 rounded-xl border border-white/10 bg-white/5 p-3 text-sm text-white/70">
          {info}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-3">
        <label className="block text-sm font-medium text-white/70">
          E-mail do responsável
        </label>
        <div className="relative">
          <FiMail className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-white/30" />
          <input
            type="email"
            value={guardianEmail}
            onChange={(e) => setGuardianEmail(e.target.value)}
            placeholder="email@do-responsavel.com"
            className="w-full rounded-xl border border-white/10 bg-white/5 py-3 pl-10 pr-4 text-white outline-none focus:border-blue-500/50"
            required
          />
        </div>
        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 py-3 font-semibold text-white disabled:opacity-50"
        >
          {hasRequest ? "Trocar e-mail do responsável" : "Enviar pedido"}
        </button>
      </form>

      <button
        onClick={handleRefresh}
        disabled={loading}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 py-3 text-sm text-white/70 disabled:opacity-50"
      >
        <FiRefreshCw className="h-4 w-4" /> Já autorizaram? Atualizar
      </button>
      <button
        onClick={logout}
        className="mt-2 w-full py-2 text-sm text-white/40 hover:text-white/70"
      >
        Sair
      </button>
    </>
  );
}
